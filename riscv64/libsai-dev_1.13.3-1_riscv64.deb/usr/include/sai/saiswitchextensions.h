/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiswitchextensions.h
 *
 * @brief   This module defines switch extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISWITCHEXTENSIONS_H_
#define __SAISWITCHEXTENSIONS_H_

#include <saiswitch.h>
#include <saitypes.h>

/**
 * @brief SAI switch attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_switch_attr_extensions_t
{
    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START = SAI_SWITCH_ATTR_END,

    /**
     * @brief Buffer monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_buffer_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_buffer_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_NOTIFY = SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Latency monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_latency_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_latency_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_NOTIFY,

    /**
     * @brief Buffer monitor microburst enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_ENABLE,

    /**
     * @brief Define the min threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MIN_THRD,

    /**
     * @brief Define the max threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MAX_THRD,

    /**
     * @brief Send the packet to CPU when the usage of buffer over the threshold
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_OVERTHRD_EVENT,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond) for the duration of microburst
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_LEVEL_THRESHOLD,

    /**
     * @brief Enable the ingress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor based on queue, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_QUEUE_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief The buffer monitor time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_TIME_INTERVAL,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_WATERMARK,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_WATERMARK,

    /**
     * @brief Define the min latency threshold(unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MIN_THRESHOLD,

    /**
     * @brief Define the max latency threshold (unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MAX_THRESHOLD,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond)
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_LEVEL_THRESHOLD,

    /**
     * @brief Set the latency monitor scan time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_INTERVAL,

    /**
     * @brief Flex Ethernet Group Event notification callback function passed to the adapter.
     *
     * Use sai_flexe_group_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_NOTIFY,

    /**
     * @brief Flex Ethernet Group Event State change notification callback function passed to the adapter.
     *
     * Use sai_flexe_event_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_STATE_CHANGE_NOTIFY,

    /**
     * @brief Set Switch Y1731 session event notification callback function passed to the adapter.
     *
     * Use sai_y1731_session_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_y1731_session_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_Y1731_SESSION_STATE_CHANGE_NOTIFY,

    /**
     * @brief Set signal degrade event notification callback function passed to the adapter.
     *
     * Use sai_signal_degrade_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_signal_degrade_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_SIGNAL_DEGRADE_EVENT_NOTIFY,

    /**
     * @brief Set PTP packet tx event notification callback function passed to the adapter.
     *
     * Use sai_packet_event_ptp_tx_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_packet_event_ptp_tx_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_PACKET_EVENT_PTP_TX_NOTIFY,

    /**
     * @brief QOS queue and port shape supported in ASIC.
     *
     * @type bool
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_QOS_SHAPE_PPS_SUPPORTED,

    /**
     * @brief Bytes per buffer cell in ASIC.
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_QOS_BYTES_PER_CELL,

    /**
     * @brief Enable/Disable all port ECMP hash
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_ECMP_HASH_ENABLE,

    /**
     * @brief MOX session event notification callback function passed to the adapter.
     *
     * Use sai_monitor_mox_session_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_mox_session_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_EVENT_NOTIFY,

    /**
     * @brief MOX session flow aging time(s).
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FLOW_AGING_TIME,

    /**
     * @brief MOX session new flow first packet export enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FIRST_PACKET_EXPORT_ENABLE,

    /**
     * @brief MONITOR MOX supported in ASIC.
     *
     * @type bool
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SUPPORTED,

    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_END

} sai_switch_attr_extensions_t;

typedef struct _sai_packet_event_ptp_tx_notification_data_t
{
    /**
     * @brief Tx port
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t tx_port;

    /** PTP message type */
    uint32_t msg_type;

    /** Attributes count */
    uint32_t ptp_seq_id;

    sai_timespec_t tx_timestamp;

} sai_packet_event_ptp_tx_notification_data_t;

/**
 * @brief PTP Packet tx notification callback
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Pointer to packet event notification for PTP tx data array
 */
typedef void (*sai_packet_event_ptp_tx_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_packet_event_ptp_tx_notification_data_t *data);

typedef enum _sai_signal_degrade_status_t
{
    /** Detect */
    SAI_SIGNAL_DEGRADE_STATUS_DETECT,

    /** Recover */
    SAI_SIGNAL_DEGRADE_STATUS_RECOVER,

} sai_signal_degrade_status_t;

/**
 * @brief Defines the signal degrade status of the Port
 */
typedef struct _sai_port_sd_notification_t
{
    /**
     * @brief Port id
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t port_id;

    /** Port signal degrade state */
    sai_signal_degrade_status_t sd_status;

} sai_port_sd_notification_t;

/**
 * @brief Port signal degrade event notification
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of port signal degrade status
 */
typedef void (*sai_signal_degrade_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_port_sd_notification_t *data);

#endif /* __SAISWITCHEXTENSIONS_H_ */
