/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saidtelextensions.h
 *
 * @brief   This module defines DTEL extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIDTELEXTENSIONS_H_
#define __SAIDTELEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief DTEL level 2 port mode
 *
 * @warning experimental
 */
typedef enum _sai_dtel_int_lv2_port_mode_t
{
    /** Global source port + Global destination port */
    SAI_DTEL_INT_LV2_PORT_MODE_GPORT,

    /** Logic source port + Logic destination port */
    SAI_DTEL_INT_LV2_PORT_MODE_LOGIC_PORT,

    /** L3 source interface & destination interface */
    SAI_DTEL_INT_LV2_PORT_MODE_INTERFACE

} sai_dtel_int_lv2_port_mode_t;

/**
 * @brief SAI DTEL attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_dtel_attr_extensions_t
{
    SAI_DTEL_ATTR_EXTENSIONS_RANGE_START = SAI_DTEL_ATTR_END,

    /**
     * @brief Level 2 port mode
     *
     * @warning experimental
     *
     * @type sai_dtel_int_lv2_port_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_DTEL_INT_LV2_PORT_MODE_INTERFACE
     */
    SAI_DTEL_ATTR_INT_LV2_PORT_MODE = SAI_DTEL_ATTR_EXTENSIONS_RANGE_START,

    SAI_DTEL_ATTR_EXTENSIONS_RANGE_END

} sai_dtel_attr_extensions_t;

/**
 * @brief SAI DTEL int session attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_dtel_int_session_attr_extensions_t
{
    SAI_DTEL_INT_SESSION_ATTR_EXTENSIONS_RANGE_START = SAI_DTEL_INT_SESSION_ATTR_END,

    /**
     * @brief Collect hop latency
     *
     * @warning experimental
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_HOP_LATENCY = SAI_DTEL_INT_SESSION_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Collect egress port Tx utilization
     *
     * @warning experimental
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_EPTU,

    /**
     * @brief Collect level 2 ports
     *
     * @warning experimental
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_SWITCH_LV2_PORTS,

    /**
     * @brief Collect queue drop
     *
     * @warning experimental
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_DTEL_INT_SESSION_ATTR_COLLECT_QUEUE_DROP,

    SAI_DTEL_INT_SESSION_ATTR_EXTENSIONS_RANGE_END

} sai_dtel_int_session_attr_extensions_t;

/**
 * @brief SAI DTEL attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_dtel_report_session_attr_extensions_t
{
    SAI_DTEL_REPORT_SESSION_ATTR_EXTENSIONS_RANGE_START = SAI_DTEL_REPORT_SESSION_ATTR_END,

    /**
     * @brief DTEL report port
     *
     * @warning experimental
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_PORT
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_DTEL_REPORT_SESSION_ATTR_PORT = SAI_DTEL_REPORT_SESSION_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief DTEL report src MAC
     *
     * Valid when SAI_DTEL_REPORT_SESSION_ATTR_PORT != SAI_NULL_OBJECT_ID
     *
     * @type sai_mac_t
     * @flags CREATE_AND_SET
     * @default vendor
     */
    SAI_DTEL_REPORT_SESSION_ATTR_SRC_MAC,

    /**
     * @brief DTEL report dst MAC
     *
     * Valid when SAI_DTEL_REPORT_SESSION_ATTR_PORT != SAI_NULL_OBJECT_ID
     *
     * @type sai_mac_t
     * @flags CREATE_AND_SET
     * @default vendor
     */
    SAI_DTEL_REPORT_SESSION_ATTR_DST_MAC,

    SAI_DTEL_REPORT_SESSION_ATTR_EXTENSIONS_RANGE_END

} sai_dtel_report_session_attr_extensions_t;

#endif /* __SAIDTELEXTENSIONS_H_ */
