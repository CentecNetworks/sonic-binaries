/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiaclextensions.h
 *
 * @brief   This module defines SAI ACL extensions interface
 */

#ifndef __SAIACLEXTENSIONS_H_
#define __SAIACLEXTENSIONS_H_

#include <sai.h>

/**
 * @brief ACL Action Type extensions
 *
 * @flags free
 */
typedef enum _sai_acl_action_type_extensions_t
{
    /**
     * @brief Start of Extensions Action Types
     */
    SAI_ACL_ACTION_TYPE_EXTENSIONS_START = 0x00000039,

    /** Set MOX session */
    SAI_ACL_ACTION_TYPE_MOX_SESSION_OBJECT = SAI_ACL_ACTION_TYPE_EXTENSIONS_START,

    SAI_ACL_ACTION_TYPE_EXTENSIONS_END

} sai_acl_action_type_extensions_t;

/**
 * @brief Attribute Id for sai_acl_table extensions
 *
 * @flags free
 */
typedef enum _sai_acl_table_attr_extensions_t
{
    /**
     * @brief Start of Extensions Table Attrs
     */
    SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_START = 0x00004000,

    /**
     * @brief Packet Forward Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_PACKET_FORWARD_TYPE = SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Discard Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_DISCARD_TYPE,

    SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_END

} sai_acl_table_attr_extensions_t;

/**
 * @brief Attribute Id for sai_acl_entry extensions
 *
 * @flags free
 */
typedef enum _sai_acl_entry_attr_extensions_t
{
    /**
     * @brief Start of Extensions Rule Fields
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_START = 0x00003000,

    /**
     * @brief Start of Extensions Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_FIELD_START = SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief End of Extensions Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_FIELD_END,

    /**
     * @brief Start of Extensions Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_START = 0x00004000,

    /**
     * @brief MOX session
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_MOX_SESSION_OBJECT = SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_START,

    /**
     * @brief End of Extensions Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_END,

    SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_END

} sai_acl_entry_attr_extensions_t;

#endif /** __SAIACLEXTENSIONS_H_ */
