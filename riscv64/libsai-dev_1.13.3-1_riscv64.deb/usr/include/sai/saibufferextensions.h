/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saibufferextensions.h
 *
 * @brief   This module defines Buffer extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIBUFFEREXTENSIONS_H_
#define __SAIBUFFEREXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief SAI buffer profile threshold modes extensions
 *
 * @flags free
 */
typedef enum _sai_buffer_profile_threshold_mode_extensions_t
{
    /**
     * @brief Start of attributes extensions
     */
    SAI_BUFFER_PROFILE_THRESHOLD_MODE_EXTENSIONS_START = SAI_BUFFER_PROFILE_THRESHOLD_MODE_DYNAMIC + 1,

    /**
     * @brief Fast ECN
     */
    SAI_BUFFER_PROFILE_THRESHOLD_MODE_FAST_ECN = SAI_BUFFER_PROFILE_THRESHOLD_MODE_EXTENSIONS_START,

    /**
     * @brief End of attributes extensions
     */
    SAI_BUFFER_PROFILE_THRESHOLD_MODE_EXTENSIONS_END,

} sai_buffer_profile_threshold_mode_extensions_t;

/**
 * @brief SAI buffer profile attributes extensions.
 *
 * @flags free
 */
typedef enum _sai_buffer_profile_attr_extensions_t
{
    /**
     * @brief Start of attributes extensions
     */
    SAI_BUFFER_PROFILE_ATTR_EXTENSIONS_START = SAI_BUFFER_PROFILE_ATTR_END,

    /**
     * @brief Set the buffer profile fast ECN XOFF threshold in bytes
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_BUFFER_PROFILE_ATTR_FAST_ECN_XOFF_TH = SAI_BUFFER_PROFILE_ATTR_EXTENSIONS_START,

    /**
     * @brief Set the buffer profile fast ECN XON threshold in bytes
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_BUFFER_PROFILE_ATTR_FAST_ECN_XON_TH,

    /**
     * @brief End of attributes extensions
     */
    SAI_BUFFER_PROFILE_ATTR_EXTENSIONS_END,

} sai_buffer_profile_attr_extensions_t;

#endif /* __SAIBUFFEREXTENSIONS_H_ */
