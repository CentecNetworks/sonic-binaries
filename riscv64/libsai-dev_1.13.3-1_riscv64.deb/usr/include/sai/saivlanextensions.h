/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saivlanextensions.h
 *
 * @brief   This module defines vlan extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIVLANEXTENSIONS_H_
#define __SAIVLANEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief Attribute data for vlan security violation action
 */
typedef enum _sai_vlan_security_action_t
{
    /** Disable VLAN Security */
    SAI_VLAN_SECURITY_ACTION_DISABLE,

    /** VLAN Security action discard */
    SAI_VLAN_SECURITY_ACTION_DISCARD,

    /** VLAN Security action warning */
    SAI_VLAN_SECURITY_ACTION_WARNING,

    /** VLAN Security action forwarding, ignore vlan security violation */
    SAI_VLAN_SECURITY_ACTION_FORWARD,

} sai_vlan_security_action_t;

/**
 * @brief SAI vlan attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_vlan_attr_extensions_t
{
    SAI_VLAN_ATTR_EXTENSIONS_RANGE_START = SAI_VLAN_ATTR_END,

    /**
     * @brief Count of the total number of MAC addresses in the VLAN
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_VLAN_ATTR_EXTENSIONS_CURRENT_MAC_COUNT = SAI_VLAN_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Vlan security violation action.
     *
     * @type sai_vlan_security_action_t
     * @flags CREATE_AND_SET
     * @default SAI_VLAN_SECURITY_ACTION_DISABLE
     */
    SAI_VLAN_ATTR_EXTENSIONS_SECURITY_ACTION,

    SAI_VLAN_ATTR_EXTENSIONS_RANGE_END

} sai_vlan_attr_extensions_t;

#endif /* __SAIVLANEXTENSIONS_H_ */
