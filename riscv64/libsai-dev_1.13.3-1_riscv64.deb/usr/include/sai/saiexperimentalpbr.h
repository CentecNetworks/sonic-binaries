/**
 * Copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentalpbr.h
 *
 * @brief   This module defines SAI PBR interface
 */

#if !defined (__SAIEXPERIMENTALPBR_H_)
#define __SAIEXPERIMENTALPBR_H_

#include <saitypes.h>

/**
 * @defgroup SAIEXPERIMENTALPBR SAI - PBR specific API definitions
 *
 * @{
 */

/**
 * @brief Enum PBR nexthop group type
 */
typedef enum _sai_pbr_nexthop_group_type_t
{
    /** PBR nexthop group is ECMP */
    SAI_PBR_NEXTHOP_GROUP_TYPE_ECMP

} sai_pbr_nexthop_group_type_t;

/**
 * @brief Attribute id for PBR nexthop group
 */
typedef enum _sai_pbr_nexthop_group_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_PBR_NEXTHOP_GROUP_ATTR_START,

    /**
     * @brief Number of next hops in the group
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_PBR_NEXTHOP_GROUP_ATTR_NEXTHOP_COUNT = SAI_PBR_NEXTHOP_GROUP_ATTR_START,

    /**
     * @brief Next hop member list
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_PBR_NEXTHOP_GROUP_MEMBER
     */
    SAI_PBR_NEXTHOP_GROUP_ATTR_NEXTHOP_MEMBER_LIST,

    /**
     * @brief PBR nexthop group type.
     *
     * @type sai_pbr_nexthop_group_type_t
     * @flags CREATE_AND_SET
     * @default SAI_PBR_NEXTHOP_GROUP_TYPE_ECMP
     */
    SAI_PBR_NEXTHOP_GROUP_ATTR_TYPE,

    /**
     * @brief End of attributes
     */
    SAI_PBR_NEXTHOP_GROUP_ATTR_END,

    /** Custom range base value */
    SAI_PBR_NEXTHOP_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_PBR_NEXTHOP_GROUP_ATTR_CUSTOM_RANGE_END

} sai_pbr_nexthop_group_attr_t;

/**
 * @brief Attribute Id for PBR nexthop group member
 */
typedef enum _sai_pbr_nexthop_group_member_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_START,

    /**
     * @brief Next hop group id
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PBR_NEXTHOP_GROUP
     */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_NEXTHOP_GROUP_ID = SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_START,

    /**
     * @brief Next hop id
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP, SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_NEXTHOP_ID,

    /**
     * @brief End of attributes
     */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_END,

    /** Custom range base value */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_PBR_NEXTHOP_GROUP_MEMBER_ATTR_CUSTOM_RANGE_END

} sai_pbr_nexthop_group_member_attr_t;

/**
 * @brief Enum PBR nexthop type
 */
typedef enum _sai_pbr_nexthop_type_t
{
    /** PBR nexthop */
    SAI_PBR_NEXTHOP_TYPE_ROUTE,

    /** PBR nexthop group */
    SAI_PBR_NEXTHOP_TYPE_ECMP

} sai_pbr_nexthop_type_t;

/**
 * @brief Attribute Id for PBR map
 */
typedef enum _sai_pbr_map_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_PBR_MAP_ATTR_START,

    /**
     * @brief Sequence Id
     *
     * @type sai_uint32_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_PBR_MAP_ATTR_SEQUENCE = SAI_PBR_MAP_ATTR_START,

    /**
     * @brief PBR MAP for source IP address
     *
     * @type sai_ip_prefix_t
     * @flags CREATE_AND_SET
     * @default 0.0.0.0/0
     */
    SAI_PBR_MAP_ATTR_FIELD_SRC_IP,

    /**
     * @brief PBR MAP for destination IP address
     *
     * @type sai_ip_prefix_t
     * @flags CREATE_AND_SET
     * @default 0.0.0.0/0
     */
    SAI_PBR_MAP_ATTR_FIELD_DST_IP,

    /**
     * @brief L4 source port.
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_PBR_MAP_ATTR_FIELD_L4_SRC_PORT,

    /**
     * @brief L4 destination port.
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_PBR_MAP_ATTR_FIELD_L4_DST_PORT,

    /**
     * @brief IP Protocol.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PBR_MAP_ATTR_FIELD_IP_PROTOCOL,

    /**
     * @brief IP DSCP (6 bits).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PBR_MAP_ATTR_FIELD_DSCP,

    /**
     * @brief IP ECN (2 bits).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PBR_MAP_ATTR_FIELD_ECN,

    /**
     * @brief Vlan Id (12 bits).
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan true
     * @default 1
     */
    SAI_PBR_MAP_ATTR_FIELD_VLAN_ID,

    /**
     * @brief PBR nexthop value.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP, SAI_OBJECT_TYPE_NEXT_HOP_GROUP, SAI_OBJECT_TYPE_PBR_NEXTHOP_GROUP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PBR_MAP_ATTR_NEXTHOP,

    /**
     * @brief PBR nexthop default.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PBR_MAP_ATTR_NEXTHOP_DEFALUT,

    /**
     * @brief End of attributes
     */
    SAI_PBR_MAP_ATTR_END,

    /** Custom range base value */
    SAI_PBR_MAP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_PBR_MAP_ATTR_CUSTOM_RANGE_END

} sai_pbr_map_attr_t;

/**
 * @brief Create PBR nexthop group
 *
 * @param[out] pbr_nexthop_group_id PBR nexthop group id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_pbr_nexthop_group_fn)(
        _Out_ sai_object_id_t *pbr_nexthop_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove PBR nexthop group
 *
 * @param[in] pbr_nexthop_group_id PBR nexthop group id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_pbr_nexthop_group_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_id);

/**
 * @brief Set PBR nexthop group attribute
 *
 * @param[in] pbr_nexthop_group_id PBR nexthop group id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_pbr_nexthop_group_attribute_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get PBR nexthop group attribute
 *
 * @param[in] pbr_nexthop_group_id PBR nexthop group id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_pbr_nexthop_group_attribute_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Create PBR nexthop group member
 *
 * @param[out] pbr_nexthop_group_member_id PBR nexthop group member id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_pbr_nexthop_group_member_fn)(
        _Out_ sai_object_id_t *pbr_nexthop_group_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove PBR nexthop group member
 *
 * @param[in] pbr_nexthop_group_member_id PBR nexthop group member id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_pbr_nexthop_group_member_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_member_id);

/**
 * @brief Set PBR nexthop group member attribute
 *
 * @param[in] pbr_nexthop_group_member_id PBR nexthop group member id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_pbr_nexthop_group_member_attribute_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_member_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get PBR nexthop group member attribute
 *
 * @param[in] pbr_nexthop_group_member_id PBR nexthop group member id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_pbr_nexthop_group_member_attribute_fn)(
        _In_ sai_object_id_t pbr_nexthop_group_member_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Create PBR map object
 *
 * @param[out] pbr_map_id PBR map id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_pbr_map_fn)(
        _Out_ sai_object_id_t *pbr_map_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove PBR map object
 *
 * @param[in] pbr_map_id PBR map id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_pbr_map_fn)(
        _In_ sai_object_id_t pbr_map_id);

/**
 * @brief Set PBR map object attribute
 *
 * @param[in] pbr_map_id PBR map id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_pbr_map_attribute_fn)(
        _In_ sai_object_id_t pbr_map_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get PBR map object attribute
 *
 * @param[in] pbr_map_id PBR map id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_pbr_map_attribute_fn)(
        _In_ sai_object_id_t pbr_map_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief PBR methods table retrieved with sai_api_query()
 */
typedef struct _sai_pbr_api_t
{
    sai_create_pbr_nexthop_group_fn               create_pbr_nexthop_group;
    sai_remove_pbr_nexthop_group_fn               remove_pbr_nexthop_group;
    sai_set_pbr_nexthop_group_attribute_fn        set_pbr_nexthop_group_attribute;
    sai_get_pbr_nexthop_group_attribute_fn        get_pbr_nexthop_group_attribute;
    sai_create_pbr_nexthop_group_member_fn        create_pbr_nexthop_group_member;
    sai_remove_pbr_nexthop_group_member_fn        remove_pbr_nexthop_group_member;
    sai_set_pbr_nexthop_group_member_attribute_fn set_pbr_nexthop_group_member_attribute;
    sai_get_pbr_nexthop_group_member_attribute_fn get_pbr_nexthop_group_member_attribute;
    sai_create_pbr_map_fn                         create_pbr_map;
    sai_remove_pbr_map_fn                         remove_pbr_map;
    sai_set_pbr_map_attribute_fn                  set_pbr_map_attribute;
    sai_get_pbr_map_attribute_fn                  get_pbr_map_attribute;
} sai_pbr_api_t;

/**
 * @}
 */
#endif /** __SAIEXPERIMENTALPBR_H_ */
