/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saisrv6extensions.h
 *
 * @brief   This module defines SRV6 extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISRV6EXTENSIONS_H_
#define __SAISRV6EXTENSIONS_H_

#include <sai.h>

/**
 * @brief Enum defining Head-end Behavior extensions
 *
 * @flags free
 */
typedef enum _sai_srv6_sidlist_type_extensions_t
{
    SAI_SRV6_SIDLIST_TYPE_EXTENSIONS_START = SAI_SRV6_SIDLIST_TYPE_ENCAPS_RED,

    /** Endpoint Insertion of SRV6 Policy */
    SAI_SRV6_SIDLIST_TYPE_ENDPOINT_INSERT,

    /** Endpoint Insertion of SRV6 Policy with Reduced SRH */
    SAI_SRV6_SIDLIST_TYPE_ENDPOINT_INSERT_RED,

    /** Endpoint Encapsulation in a SRV6 Policy */
    SAI_SRV6_SIDLIST_TYPE_ENDPOINT_ENCAPS,

    /** Endpoint Encapsulation in a SRV6 Policy with Reduced SRH */
    SAI_SRV6_SIDLIST_TYPE_ENDPOINT_ENCAPS_RED,

    SAI_SRV6_SIDLIST_TYPE_EXTENSIONS_END

} sai_srv6_sidlist_type_extensions_t;

/**
 * @brief Enum defining Endpoint Behavior flavors for End, End.X and End.T functions extensions
 *
 * @flags free
 */
typedef enum _sai_my_sid_entry_endpoint_behavior_flavor_extensions_t
{
    SAI_MY_SID_ENTRY_ENDPOINT_BEHAVIOR_FLAVOR_EXTENSIONS_START = SAI_MY_SID_ENTRY_ENDPOINT_BEHAVIOR_FLAVOR_PSP_AND_USP_AND_USD,

    /** Continue of Compression */
    SAI_MY_SID_ENTRY_ENDPOINT_BEHAVIOR_FLAVOR_COC,

    SAI_MY_SID_ENTRY_ENDPOINT_BEHAVIOR_FLAVOR_EXTENSIONS_END

} sai_my_sid_entry_endpoint_behavior_flavor_extensions_t;

#endif /* __SAISRV6EXTENSIONS_H_ */
