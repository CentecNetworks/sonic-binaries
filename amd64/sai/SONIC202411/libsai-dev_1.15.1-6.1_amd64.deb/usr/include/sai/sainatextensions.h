/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sainatextensions.h
 *
 * @brief   This module defines SAI NAT (Network Address Translation) spec extensions
 */

#ifndef __SAINATEXTENSIONS_H_
#define __SAINATEXTENSIONS_H_

#include <sai.h>

/**
 * @brief NAT Entry Attributes for Match extensions
 *
 * @flags free
 */
typedef enum _sai_nat_type_extensions_t
{
    SAI_NAT_TYPE_EXTENSIONS_START = SAI_NAT_TYPE_DESTINATION_NAT_POOL,

    /** NAT IP address version 6 to IP address version 4 */
    SAI_NAT_TYPE_IPV6_TO_IPV4_NAT,

    /** NAT IP address version 4 to IP address version 6 */
    SAI_NAT_TYPE_IPV4_TO_IPV6_NAT,

    SAI_NAT_TYPE_EXTENSIONS_END

} sai_nat_type_extensions_t;

#endif /** __SAINATEXTENSIONS_H_ */
