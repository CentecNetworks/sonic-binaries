/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitwampextensions.h
 *
 * @brief   This module defines TWAMP extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITWAMPEXTENSIONS_H_
#define __SAITWAMPEXTENSIONS_H_

#include <sai.h>

/**
 * @brief SAI TWAMP attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_twamp_session_attr_extensions_t
{
    SAI_TWAMP_SESSION_ATTR_EXTENSIONS_RANGE_START = SAI_TWAMP_SESSION_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief L2 header inner VLAN Id.
     *
     * @type sai_uint16_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @isvlan true
     * @condition SAI_TWAMP_SESSION_ATTR_INNER_VLAN_HEADER_VALID == true
     */
    SAI_TWAMP_SESSION_ATTR_INNER_VLAN_ID = SAI_TWAMP_SESSION_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief L2 header inner packet priority (3 bits).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_TWAMP_SESSION_ATTR_INNER_VLAN_HEADER_VALID == true
     */
    SAI_TWAMP_SESSION_ATTR_INNER_VLAN_PRI,

    /**
     * @brief L2 header inner VLAN CFI (1 bit).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_TWAMP_SESSION_ATTR_VLAN_HEADER_VALID == true
     */
    SAI_TWAMP_SESSION_ATTR_INNER_VLAN_CFI,

    /**
     * @brief Inner VLAN header valid
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     * @validonly SAI_TWAMP_SESSION_ATTR_HW_LOOKUP_VALID == false
     */
    SAI_TWAMP_SESSION_ATTR_INNER_VLAN_HEADER_VALID,

    SAI_TWAMP_SESSION_ATTR_EXTENSIONS_RANGE_END

} sai_twamp_session_attr_extensions_t;

#endif /* __SAITWAMPEXTENSIONS_H_ */
