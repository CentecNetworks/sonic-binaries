/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiqueueextensions.h
 *
 * @brief   This module defines SAI QOS Queue interface extensions
 */

#ifndef __SAIQUEUEEXTENSIONS_H_
#define __SAIQUEUEEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Enum defining Queue types extensions.
 *
 * @flags free
 */
typedef enum _sai_queue_type_extensions_t
{
    SAI_QUEUE_TYPE_EXTENSIONS_START = SAI_QUEUE_TYPE_FABRIC_TX,

    /** H/w Queue for service */
    SAI_QUEUE_TYPE_SERVICE,

    SAI_QUEUE_TYPE_EXTENSIONS_END

} sai_queue_type_extensions_t;

/**
 * @brief Enum defining queue attributes extensions.
 *
 * @flags free
 */
typedef enum _sai_queue_attr_extensions_t
{
    SAI_QUEUE_ATTR_EXTENSIONS_RANGE_START = SAI_QUEUE_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Service Id, if this queue is used for service
     * the same service id should used in schedule group, and in bridge port,tunnel port
     *
     * @type sai_uint16_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @isvlan false
     * @condition SAI_QUEUE_ATTR_TYPE == SAI_QUEUE_TYPE_SERVICE
     */
    SAI_QUEUE_ATTR_SERVICE_ID = SAI_QUEUE_ATTR_EXTENSIONS_RANGE_START,

    SAI_QUEUE_ATTR_EXTENSIONS_RANGE_END

} sai_queue_attr_extensions_t;

#endif /** __SAIQUEUEEXTENSIONS_H_ */
