/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saimplsextensions.h
 *
 * @brief   This module defines SAI MPLS interface extensions
 */

#ifndef __SAIMPLSEXTENSIONS_H_
#define __SAIMPLSEXTENSIONS_H_

#include <sai.h>

/**
 * @brief SAI in segment PSC type extensions
 *
 * @flags free
 */
typedef enum _sai_inseg_entry_psc_type_extensions_t
{
    SAI_INSEG_ENTRY_PSC_TYPE_EXTENSIONS_START = SAI_INSEG_ENTRY_PSC_TYPE_LLSP,

    /**
     * @brief Do not use MPLS label infers TC and COLOR
     */
    SAI_INSEG_ENTRY_PSC_TYPE_NONE,

    SAI_INSEG_ENTRY_PSC_TYPE_EXTENSIONS_END

} sai_inseg_entry_psc_type_extensions_t;

/**
 * @brief MPLS in-segment configured role
 */
typedef enum _sai_inseg_entry_configured_role_t
{
    /** MPLS in-segment is primary */
    SAI_INSEG_ENTRY_CONFIGURED_ROLE_PRIMARY,

    /** MPLS in-segment is standby */
    SAI_INSEG_ENTRY_CONFIGURED_ROLE_STANDBY,

} sai_inseg_entry_configured_role_t;

/**
 * @brief MPLS in-segment observed role
 */
typedef enum _sai_inseg_entry_frr_observed_role_t
{
    /** MPLS in-segment is active */
    SAI_INSEG_ENTRY_FRR_OBSERVED_ROLE_ACTIVE,

    /** MPLS in-segment is inactive */
    SAI_INSEG_ENTRY_FRR_OBSERVED_ROLE_INACTIVE,

} sai_inseg_entry_frr_observed_role_t;

/**
 * @brief Attribute Id for SAI in segment extensions
 *
 * @flags free
 */
typedef enum _sai_inseg_entry_attr_extensions_t
{
    SAI_INSEG_ENTRY_ATTR_EXTENSIONS_RANGE_START = SAI_INSEG_ENTRY_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief The tunnel id
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TUNNEL
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_INSEG_ENTRY_ATTR_DECAP_TUNNEL_ID = SAI_INSEG_ENTRY_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Fast Reroute nexthop group
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_INSEG_ENTRY_ATTR_FRR_NHP_GRP,

    /**
     * @brief Fast Reroute configured Role in packet receiving direction
     * valid when SAI_INSEG_ENTRY_ATTR_FRR_NHP_GRP != NULL
     *
     * @type sai_inseg_entry_configured_role_t
     * @flags CREATE_AND_SET
     * @default SAI_INSEG_ENTRY_CONFIGURED_ROLE_PRIMARY
     */
    SAI_INSEG_ENTRY_ATTR_FRR_CONFIGURED_ROLE,

    /**
     * @brief Fast Reroute observed Role in packet receiving direction
     *
     * valid when SAI_INSEG_ENTRY_ATTR_FRR_NHP_GRP != NULL
     *
     * @type sai_inseg_entry_frr_observed_role_t
     * @flags READ_ONLY
     * @isresourcetype true
     */
    SAI_INSEG_ENTRY_ATTR_FRR_OBSERVED_ROLE,

    /**
     * @brief Fast Reroute observed Role inactive discard in receiving direction
     * validonly SAI_INSEG_ENTRY_ATTR_FRR_NHP_GRP != NULL
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_INSEG_ENTRY_ATTR_FRR_INACTIVE_RX_DISCARD,

    /**
     * @brief Attach/Detach policer to MPLS in-segment
     *
     * Set policer id = #SAI_NULL_OBJECT_ID to disable policer on MPLS in-segment.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_POLICER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_INSEG_ENTRY_ATTR_POLICER_ID,

    /**
     * @brief Service id for MPLS in-segment entry
     *
     * used for H-QOS, set to service schedule group service id
     * set to 0 means disable H-QOS on MPLS label, usually used in PW label
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_INSEG_ENTRY_ATTR_SERVICE_ID,

    SAI_INSEG_ENTRY_ATTR_EXTENSIONS_RANGE_END

} sai_inseg_entry_attr_extensions_t;

#endif /** __SAIMPLSEXTENSIONS_H_ */
