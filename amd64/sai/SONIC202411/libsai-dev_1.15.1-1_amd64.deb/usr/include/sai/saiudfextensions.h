/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiudfextensions.h
 *
 * @brief   This module defines SAI UDF (User Defined Field) interface extensions
 */

#ifndef __SAIUDFEXTENSIONS_H_
#define __SAIUDFEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Attribute id for UDF match extensions
 *
 * @flags free
 */
typedef enum _sai_udf_match_attr_extensions_t
{
    SAI_UDF_MATCH_ATTR_EXTENSIONS_RANGE_START = SAI_UDF_MATCH_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief UDF MPLS label number match rule
     *
     * Default to None
     *
     * @type sai_acl_field_data_t sai_uint8_t
     * @flags CREATE_ONLY
     * @default 0
     */
    SAI_UDF_MATCH_ATTR_MPLS_LABEL_NUM = SAI_UDF_MATCH_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief UDF L4 src port match rule
     *
     * Default to None
     *
     * @type sai_acl_field_data_t sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan false
     * @default 0
     */
    SAI_UDF_MATCH_ATTR_L4_SRC_PORT,

    /**
     * @brief UDF L4 destination port match rule
     *
     * Default to None
     *
     * @type sai_acl_field_data_t sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan false
     * @default 0
     */
    SAI_UDF_MATCH_ATTR_L4_DST_PORT,

    SAI_UDF_MATCH_ATTR_EXTENSIONS_RANGE_END

} sai_udf_match_attr_extensions_t;

#endif /** __SAIUDFEXTENSIONS_H_ */
