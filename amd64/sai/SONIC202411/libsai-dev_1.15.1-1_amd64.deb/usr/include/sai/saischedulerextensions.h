/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saischedulerextensions.h
 *
 * @brief   This module defines SAI QOS Scheduler interface extensions
 */

#ifndef __SAISCHEDULEREXTENSIONS_H_
#define __SAISCHEDULEREXTENSIONS_H_

#include <sai.h>

/**
 * @brief Enum defining scheduler attributes extensions.
 *
 * @flags free
 */
typedef enum _sai_scheduler_attr_extensions_t
{
    SAI_SCHEDULER_ATTR_EXTENSIONS_RANGE_START = SAI_SCHEDULER_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Scheduling algorithm priority
     *
     * value 255 means invalid
     * Range [0 - 7].
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 255
     */
    SAI_SCHEDULER_ATTR_SCHEDULING_PRIORITY = SAI_SCHEDULER_ATTR_EXTENSIONS_RANGE_START,

    SAI_SCHEDULER_ATTR_EXTENSIONS_RANGE_END

} sai_scheduler_attr_extensions_t;

#endif /** __SAISCHEDULEREXTENSIONS_H_ */
