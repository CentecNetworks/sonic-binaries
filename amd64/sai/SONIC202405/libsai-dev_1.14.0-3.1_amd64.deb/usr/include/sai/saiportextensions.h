/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiportextensions.h
 *
 * @brief   This module defines port extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIPORTEXTENSIONS_H_
#define __SAIPORTEXTENSIONS_H_

#include <saiport.h>
#include <saitypes.h>

/**
 * @brief SAI port type extensions
 *
 * @flags free
 */
typedef enum _sai_port_type_extensions_t
{
    SAI_PORT_TYPE_EXTENSIONS_START = SAI_PORT_TYPE_RECYCLE,

    /** Flex Ethernet CLIENT */
    SAI_PORT_TYPE_FLEXE_CLIENT,

    SAI_PORT_TYPE_EXTENSIONS_END

} sai_port_type_extensions_t;

/**
 * @brief SAI port attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_port_attr_extensions_t
{
    SAI_PORT_ATTR_EXTENSIONS_RANGE_START = SAI_PORT_ATTR_END,

    /**
     * @brief Ingress asymmetry value
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_INGRESS_ASYMMETRY_DELAY = SAI_PORT_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Egress asymmetry value
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_EGRESS_ASYMMETRY_DELAY,

    /**
     * @brief Path delay for Peer-to-peer Transparent Clock, it is the link delay between the device and the linked device
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_PATH_DELAY,

    /**
     * @brief Set port domain id, and so far, only one domain is supported, and domain ID cannot be 0.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_PTP_DOMAIN
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_PTP_DOMAIN_ID,

    /**
     * @brief Ethernet Segment for the port
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_ES
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_ES,

    /**
     * @brief Enable/Disable Y1731/Ether OAM function
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_Y1731_ENABLE,

    /**
     * @brief Enable/Disable Y1731/Ether OAM Loss Measurement function
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_Y1731_LM_ENABLE,

    /**
     * @brief Bit vector Maintenance Domain Intermediate Point Enable/Disable Level for Y1731/Ether OAM
     * valid from bit 0 to bit 7, each bit indicate one level
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_Y1731_MIP_ENABLE,

    /**
     * @brief MAC address on the port
     * it can be use to identify received Unicast Y.1731 OAM packet to the port
     * also it is used as source MAC address when transmit Y.1731 OAM packet
     *
     * @type sai_mac_t
     * @flags CREATE_AND_SET
     * @default vendor
     */
    SAI_PORT_ATTR_MAC_ADDRESS,

    /**
     * @brief Enable/Disable segment route for IPv6 SID lookup
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_SR_SID_ENABLE,

    /**
     * @brief Port led mode.
     *
     * @type sai_port_led_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_PORT_LED_MODE_1_RXLNK_BIACT
     */
    SAI_PORT_ATTR_LED_MODE,

    /**
     * @brief Flexible Ethernet PHY Enable
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_LOGICAL
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_IS_FLEXE_PHY,

    /**
     * @brief Flexible Ethernet PHY Number
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_LOGICAL and SAI_PORT_ATTR_IS_FLEXE_PHY == true
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 1
     */
    SAI_PORT_ATTR_FLEXE_PHY_NUM,

    /**
     * @brief Flexible Ethernet Client Primary
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_PRIMARY,

    /**
     * @brief Flexible Ethernet Client Standby
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_STANDBY,

    /**
     * @brief Flex Ethernet Client auto protect switch switch-over mode
     *
     * @type sai_port_flexe_client_switchover_mode_t
     * @flags CREATE_ONLY
     * @default SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_PLUS_1
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE,

    /**
     * @brief Trigger a switch-over from primary to backup Flex Ethernet Client
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_RX_SET_SWITCHOVER,

    /**
     * @brief Trigger a switch-over from primary to backup Flex Ethernet Client
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_TX_SET_SWITCHOVER,

    /**
     * @brief Full Duplex setting
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_PORT_ATTR_PHY_FULL_DUPLEX_MODE,

    /**
     * @brief Auto Negotiation configuration for PHY
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_PHY_AUTO_NEO_MODE,

    /**
     * @brief Query/Configure list of Advertised port speed (Full-Duplex) in Mbps for PHY
     *
     * Used when auto negotiation is on. Empty list means all supported values are enabled.
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_PORT_ATTR_PHY_ADVERTISED_SPEED,

    /**
     * @brief Query/Configure list of Advertised HALF-Duplex speed in Mbps for PHY
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_PORT_ATTR_PHY_ADVERTISED_HALF_DUPLEX_SPEED,

    /**
     * @brief PW protect ingress ACL lookup enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_PW_PROTECT_INGRESS_ACL_LOOKUP_ENABLE,

    /**
     * @brief DHCP and DHCPV6 packet action for port
     *
     * @type sai_packet_action_t
     * @flags CREATE_AND_SET
     * @default SAI_PACKET_ACTION_LOG
     */
    SAI_PORT_ATTR_DHCP_PACKET_ACTION,

    /**
     * @brief PORT_INIT_DONE
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_CUSTOM_PORT_INIT_DONE,

    /**
     * @brief Snoop tunnel inner packet information
     *
     * Force snooping inner payload, regardless of data plane process of packet flow, mainly used for tunnel packet
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_SNOOP_INNER_PARSER_ENABLE,

    /**
     * @brief ACL use tunnel inner packet information
     *
     * Used when ACL key match inner packet information, even if it is tunnel packet in transit node
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_ACL_USE_INNER_INFO_ENABLE,

    /**
     * @brief Is customer vlan domain
     *
     * This is a flag which states that the port is in customer vlan domain
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_IS_CVLAN_DOMAIN,

    /**
     * @brief Port cut through enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_CUT_THROUGH_ENABLE,

    /* Add new experimental port attributes above this line */

    SAI_PORT_ATTR_EXTENSIONS_RANGE_END

} sai_port_attr_extensions_t;

/**
 * @brief Attribute data for #SAI_PORT_ATTR_INTERFACE_TYPE
 * Used for selecting electrical interface with specific electrical pin and signal quality
 *
 * @flags free
 */
typedef enum _sai_port_interface_type_extensions_t
{
    SAI_PORT_INTERFACE_TYPE_EXTENSIONS_START = SAI_PORT_INTERFACE_TYPE_MAX,

    /** Interface type Serial GMII */
    SAI_PORT_INTERFACE_TYPE_SGMII = SAI_PORT_INTERFACE_TYPE_EXTENSIONS_START,

    /** Interface type Quad Serial GMII */
    SAI_PORT_INTERFACE_TYPE_QSGMII,

    SAI_PORT_INTERFACE_TYPE_EXTENSIONS_END

} sai_port_interface_type_extensions_t;

/**
 * @brief Attribute data for #SAI_PORT_ATTR_LED_MODE
 */
typedef enum _sai_port_led_mode_t
{
    /** One bit, rx link + bi activity */
    SAI_PORT_LED_MODE_1_RXLNK_BIACT,

    /** One bit, force on */
    SAI_PORT_LED_MODE_1_FORCE_ON,

    /** One bit, force off */
    SAI_PORT_LED_MODE_1_FORCE_OFF,

    /** One bit, bi activity */
    SAI_PORT_LED_MODE_1_BIACT,

    /** Two bits, first: rx link; second: bi activity */
    SAI_PORT_LED_MODE_2_RXLNK_BIACT,

    /** Two bits, first: off; second: rx link + bi activity */
    SAI_PORT_LED_MODE_2_OFF_RXLNKBIACT,

    /** Two bits, first: rx link + bi activity; second: off */
    SAI_PORT_LED_MODE_2_RXLNKBIACT_OFF,

    /** Two bits, all force off */
    SAI_PORT_LED_MODE_2_FORCE_OFF,

    /** Two bits, first: off; second: bi activity */
    SAI_PORT_LED_MODE_2_OFF_BIACT,

    /** Two bits, first: bi activity; second: off */
    SAI_PORT_LED_MODE_2_BIACT_OFF,

    /** Two bits, first: force off; second: force on */
    SAI_PORT_LED_MODE_2_OFF_ON,

    /** Two bits, first: force on; second: force off */
    SAI_PORT_LED_MODE_2_ON_OFF,

    /** Two bits, first: tx link(rx link+fault); second: rx link+bi activity */
    SAI_PORT_LED_MODE_2_TXLNK_RXLNKBIACT,

    /** Two bits, first: tx link(rx link+fault); second: bi activity */
    SAI_PORT_LED_MODE_2_TXLNK_BIACT,

    /** Two bits, first: tx link(rx link+fault); second: force off */
    SAI_PORT_LED_MODE_2_TXLNK_OFF,

    /** Two bits, first: rx link+bi activity; second: tx link(rx link+fault) */
    SAI_PORT_LED_MODE_2_RXLNKBIACT_TXLNK,

    /** Two bits, first: bi activity; second: tx link(rx link+fault) */
    SAI_PORT_LED_MODE_2_BIACT_TXLNK,

    /** Two bits, first: force off; second: tx link(rx link+fault) */
    SAI_PORT_LED_MODE_2_OFF_TXLNK,
} sai_port_led_mode_t;

/**
 * @brief Attribute data for #SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE
 */
typedef enum _sai_port_flexe_client_switchover_mode_t
{
    /** 1+1 */
    SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_PLUS_1,

    /** 1:1 */
    SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_BY_1,

} sai_port_flexe_client_switchover_mode_t;

/**
 * @brief SAI port stat extensions.
 *
 * @flags free
 */
typedef enum _sai_port_stat_extensions_t
{
    SAI_PORT_STAT_EXTENSIONS_RANGE_START = SAI_PORT_STAT_END,

    /** DASH port LB_FAST_PATH_ICMP_IN_BYTES stat count */
    SAI_PORT_STAT_LB_FAST_PATH_ICMP_IN_BYTES = SAI_PORT_STAT_EXTENSIONS_RANGE_START,

    /** DASH port LB_FAST_PATH_ICMP_IN_PACKETS stat count */
    SAI_PORT_STAT_LB_FAST_PATH_ICMP_IN_PACKETS,

    /** DASH port LB_FAST_PATH_ENI_MISS_BYTES stat count */
    SAI_PORT_STAT_LB_FAST_PATH_ENI_MISS_BYTES,

    /** DASH port LB_FAST_PATH_ENI_MISS_PACKETS stat count */
    SAI_PORT_STAT_LB_FAST_PATH_ENI_MISS_PACKETS,

    SAI_PORT_STAT_IF_IN_RECEIVES,

    SAI_PORT_STAT_IF_OUT_TRANSMITS,

    SAI_PORT_STAT_IP_OUT_TRANSMITS,

    SAI_PORT_STAT_IPV6_OUT_TRANSMITS,

    SAI_PORT_STAT_PFC_RX_PKTS,

    SAI_PORT_STAT_PFC_TX_PKTS,

    /* Add new experimental port stats above this line */

    SAI_PORT_STAT_EXTENSIONS_RANGE_END

} sai_port_stat_extensions_t;

typedef enum _sai_signal_degrade_status_t
{
    /** Detect */
    SAI_SIGNAL_DEGRADE_STATUS_DETECT,

    /** Recover */
    SAI_SIGNAL_DEGRADE_STATUS_RECOVER,

} sai_signal_degrade_status_t;

/**
 * @brief Defines the signal degrade status of the Port
 */
typedef struct _sai_port_sd_notification_t
{
    /**
     * @brief Port id
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t port_id;

    /** Port signal degrade state */
    sai_signal_degrade_status_t sd_status;

} sai_port_sd_notification_t;

/**
 * @brief Port signal degrade event notification
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of port signal degrade status
 */
typedef void (*sai_signal_degrade_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_port_sd_notification_t *data);

#endif /* __SAIPORTEXTENSIONS_H_ */
