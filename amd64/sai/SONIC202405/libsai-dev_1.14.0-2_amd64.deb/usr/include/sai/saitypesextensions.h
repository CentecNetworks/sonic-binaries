/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitypesextensions.h
 *
 * @brief   This module defines type extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITYPESEXTENSIONS_H_
#define __SAITYPESEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief SAI object type extensions
 *
 * @flags free
 */
typedef enum _sai_object_type_extensions_t
{
    SAI_OBJECT_TYPE_EXTENSIONS_RANGE_START = SAI_OBJECT_TYPE_MAX,

    SAI_OBJECT_TYPE_TABLE_BITMAP_CLASSIFICATION_ENTRY = SAI_OBJECT_TYPE_EXTENSIONS_RANGE_START,

    SAI_OBJECT_TYPE_TABLE_BITMAP_ROUTER_ENTRY,

    SAI_OBJECT_TYPE_TABLE_META_TUNNEL_ENTRY,

    SAI_OBJECT_TYPE_DASH_ACL_GROUP,

    SAI_OBJECT_TYPE_DASH_ACL_RULE,

    SAI_OBJECT_TYPE_DIRECTION_LOOKUP_ENTRY,

    SAI_OBJECT_TYPE_ENI_ETHER_ADDRESS_MAP_ENTRY,

    SAI_OBJECT_TYPE_ENI,

    SAI_OBJECT_TYPE_INBOUND_ROUTING_ENTRY,

    SAI_OBJECT_TYPE_METER_BUCKET,

    SAI_OBJECT_TYPE_METER_POLICY,

    SAI_OBJECT_TYPE_METER_RULE,

    SAI_OBJECT_TYPE_OUTBOUND_CA_TO_PA_ENTRY,

    SAI_OBJECT_TYPE_OUTBOUND_ROUTING_ENTRY,

    SAI_OBJECT_TYPE_VNET,

    SAI_OBJECT_TYPE_PA_VALIDATION_ENTRY,

    SAI_OBJECT_TYPE_VIP_ENTRY,

    SAI_OBJECT_TYPE_NPM_SESSION,

    SAI_OBJECT_TYPE_ES,

    SAI_OBJECT_TYPE_Y1731_MEG,

    SAI_OBJECT_TYPE_Y1731_SESSION,

    SAI_OBJECT_TYPE_Y1731_REMOTE_MEP,

    SAI_OBJECT_TYPE_PTP_DOMAIN,

    SAI_OBJECT_TYPE_SYNCE,

    SAI_OBJECT_TYPE_MONITOR_BUFFER_MONITOR,

    SAI_OBJECT_TYPE_MONITOR_LATENCY_MONITOR,

    SAI_OBJECT_TYPE_FLEXE_GROUP,

    SAI_OBJECT_TYPE_FLEXE_SLOT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT_CROSS_CONNECT,

    SAI_OBJECT_TYPE_VLAN_CLASS,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_FLOW_FIELD,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_EVENT,

    /* Add new experimental object types above this line */

    /* RANGE_END = the last enum value + 6,including four internal object types which users donot need to care */

    SAI_OBJECT_TYPE_EXTENSIONS_RANGE_END = SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_EVENT + 6

} sai_object_type_extensions_t;

typedef enum _sai_dash_direction_t
{
    SAI_DASH_DIRECTION_INVALID,

    SAI_DASH_DIRECTION_OUTBOUND,

    SAI_DASH_DIRECTION_INBOUND,

} sai_dash_direction_t;

typedef enum _sai_dash_encapsulation_t
{
    SAI_DASH_ENCAPSULATION_INVALID,

    SAI_DASH_ENCAPSULATION_VXLAN,

    SAI_DASH_ENCAPSULATION_NVGRE,

} sai_dash_encapsulation_t;

typedef enum _sai_dash_tunnel_dscp_mode_t
{
    SAI_DASH_TUNNEL_DSCP_MODE_PRESERVE_MODEL,

    SAI_DASH_TUNNEL_DSCP_MODE_PIPE_MODEL,

} sai_dash_tunnel_dscp_mode_t;

typedef enum _sai_stats_count_mode_t
{
    /** Count packet and byte */
    SAI_STATS_COUNT_MODE_PACKET_AND_BYTE,

    /** Count only packet */
    SAI_STATS_COUNT_MODE_PACKET,

    /** Count only byte */
    SAI_STATS_COUNT_MODE_BYTE,

    /** Counting is disabled */
    SAI_STATS_COUNT_MODE_NONE

} sai_stats_count_mode_t;

/**
 * @brief Enum defining MPLS out segment type extensions
 *
 * @flags free
 */
typedef enum _sai_outseg_type_extensions_t
{
    SAI_OUTSEG_TYPE_EXTENSIONS_START = SAI_OUTSEG_TYPE_SWAP,

    /** Out segment of last but one node, label stack depth is zero */
    SAI_OUTSEG_TYPE_PHP,

    SAI_OUTSEG_TYPE_EXTENSIONS_END

} sai_outseg_type_extensions_t;

#endif /* __SAITYPESEXTENSIONS_H_ */

