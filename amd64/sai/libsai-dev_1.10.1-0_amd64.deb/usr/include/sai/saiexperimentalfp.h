/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentalfp.h
 *
 * @brief   This module defines SAI Flex Program
 */

#if !defined (__SAIEXPERIMENTALFP_H_)
#define __SAIEXPERIMENTALFP_H_

#include <saitypes.h>

/**
 * @brief Enum Flex Program type
 */
typedef enum _sai_fp_type_t
{
    /** Flex Program type insert */
    SAI_FP_TYPE_INSERT,

    /** Flex Program type delete */
    SAI_FP_TYPE_DELETE,

    /** Flex Program type replace */
    SAI_FP_TYPE_REPLACE

} sai_fp_type_t;

/**
 * @brief Enum Flex Program offset type
 */
typedef enum _sai_fp_offset_type_t
{
    /** Flex Program offset type L2 */
    SAI_FP_OFFSET_TYPE_L2,

    /** Flex Program offset type L3 */
    SAI_FP_OFFSET_TYPE_L3,

    /** Flex Program offset type L4 */
    SAI_FP_OFFSET_TYPE_L4

} sai_fp_offset_type_t;

/**
 * @brief Attribute Id in sai_set_fp_attribute() and
 * sai_get_fp_attribute() calls
 */
typedef enum _sai_fp_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_FP_ATTR_START,

    /**
     * @brief Flex Program object type
     *
     * @type sai_fp_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_FP_ATTR_TYPE = SAI_FP_ATTR_START,

    /**
     * @brief Flex Program offset type
     *
     * @type sai_fp_offset_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_FP_ATTR_OFFSET_TYPE,

    /**
     * @brief Flex Program edit offset, only for insert or replace
     * means start offset from offset type layer, in bytes
     *
     * @type sai_uint8_t
     * @flags CREATE_ONLY
     * @default 0
     * @validonly SAI_FP_ATTR_TYPE == SAI_FP_TYPE_INSERT or SAI_FP_ATTR_TYPE == SAI_FP_TYPE_DELETE or SAI_FP_ATTR_TYPE == SAI_FP_TYPE_REPLACE
     */
    SAI_FP_ATTR_EDIT_OFFSET,

    /**
     * @brief Flex Program edit length, only for insert or delete, in bytes
     *
     * @type sai_uint8_t
     * @flags CREATE_ONLY
     * @default 0
     * @validonly SAI_FP_ATTR_TYPE == SAI_FP_TYPE_INSERT or SAI_FP_ATTR_TYPE == SAI_FP_TYPE_DELETE
     */
    SAI_FP_ATTR_EDIT_LENGTH,

    /**
     * @brief Flex Program edit data list, only for insert or replace
     *
     * @type sai_u32_list_t
     * @flags CREATE_ONLY
     * @default empty
     * @validonly SAI_FP_ATTR_TYPE == SAI_FP_TYPE_INSERT or SAI_FP_ATTR_TYPE == SAI_FP_TYPE_REPLACE
     */
    SAI_FP_ATTR_EDIT_DATA_LIST,

    /**
     * @brief Flex Program edit data offset list, only for replace, use bits
     *
     * @type sai_u32_list_t
     * @flags CREATE_ONLY
     * @default empty
     * @validonly SAI_FP_ATTR_TYPE == SAI_FP_TYPE_REPLACE
     */
    SAI_FP_ATTR_REPLACE_DATA_OFFSET_LIST,

    /**
     * @brief Flex Program edit data length list, only for replace, use bits
     *
     * @type sai_u8_list_t
     * @flags CREATE_ONLY
     * @default empty
     * @validonly SAI_FP_ATTR_TYPE == SAI_FP_TYPE_REPLACE
     */
    SAI_FP_ATTR_REPLACE_DATA_LENGTH_LIST,

    /**
     * @brief End of attributes
     */
    SAI_FP_ATTR_END,

    /** Custom range base value */
    SAI_FP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_FP_ATTR_CUSTOM_RANGE_END
} sai_fp_attr_t;

/**
 * @brief Create flex program object
 *
 * @param[out] fp_id Flex program id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_fp_fn)(
        _Out_ sai_object_id_t *fp_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove flex program object
 *
 * @param[in] fp_id Flex program id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_fp_fn)(
        _In_ sai_object_id_t fp_id);

/**
 * @brief Set flex program object attribute
 *
 * @param[in] fp_id Flex program id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_fp_attribute_fn)(
        _In_ sai_object_id_t fp_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get flex program object attribute
 *
 * @param[in] fp_id Flex program id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_fp_attribute_fn)(
        _In_ sai_object_id_t fp_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Flex program methods table retrieved with sai_api_query()
 */
typedef struct _sai_fp_api_t
{
    sai_create_fp_fn        create_fp;
    sai_remove_fp_fn        remove_fp;
    sai_set_fp_attribute_fn set_fp_attribute;
    sai_get_fp_attribute_fn get_fp_attribute;

} sai_fp_api_t;

/**
 * @}
 */

#endif /** __SAIEXPERIMENTALFP_H_ */

