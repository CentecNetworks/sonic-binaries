/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiportextensions.h
 *
 * @brief   This module defines port extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIPORTEXTENSIONS_H_
#define __SAIPORTEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief Attribute data for #SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE
 */
typedef enum _sai_port_flexe_client_switchover_mode_t
{
    /** 1+1 */
    SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_PLUS_1,

    /** 1:1 */
    SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_BY_1,

} sai_port_flexe_client_switchover_mode_t;

/**
 * @brief SAI vlan attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_port_attr_extensions_t
{
    SAI_PORT_ATTR_EXTENSIONS_RANGE_START = SAI_PORT_ATTR_END,

    /**
     * @brief Ingress asymmetry value
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_INGRESS_ASYMMETRY_DELAY = SAI_PORT_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Egress asymmetry value
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_EGRESS_ASYMMETRY_DELAY,

    /**
     * @brief Path delay for Peer-to-peer Transparent Clock, it is the link delay between the device and the linked device
     *
     * @type sai_uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_PTP_PATH_DELAY,

    /**
     * @brief Set port domain id, and so far, only one domain is supported, and domain ID cannot be 0.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_PTP_DOMAIN
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_PTP_DOMAIN_ID,

    /**
     * @brief Ethernet Segment for the port
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_ES
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_ES,

    /**
     * @brief Enable/Disable Y1731/Ether OAM function
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_Y1731_ENABLE,

    /**
     * @brief Enable/Disable Y1731/Ether OAM Loss Measurement function
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_Y1731_LM_ENABLE,

    /**
     * @brief Bit vector Maintenance Domain Intermediate Point Enable/Disable Level for Y1731/Ether OAM
     * valid from bit 0 to bit 7, each bit indicate one level
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_Y1731_MIP_ENABLE,

    /**
     * @brief MAC address on the port
     * it can be use to identify received Unicast Y.1731 OAM packet to the port
     * also it is used as source MAC address when transmit Y.1731 OAM packet
     *
     * @type sai_mac_t
     * @flags CREATE_AND_SET
     * @default vendor
     */
    SAI_PORT_ATTR_MAC_ADDRESS,

    /**
     * @brief Enable/Disable segment route for IPv6 SID lookup
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_SR_SID_ENABLE,

    /**
     * @brief Flexible Ethernet PHY Enable
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_LOGICAL
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_IS_FLEXE_PHY,

    /**
     * @brief Flexible Ethernet PHY Number
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_LOGICAL and SAI_PORT_ATTR_IS_FLEXE_PHY == true
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 1
     */
    SAI_PORT_ATTR_FLEXE_PHY_NUM,

    /**
     * @brief Flex Ethernet Client auto protect switch switch-over mode
     *
     * condition SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_FLEXE_CLIENT
     *
     * @type sai_port_flexe_client_switchover_mode_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE,

    /**
     * @brief Trigger a switch-over from primary to backup Flex Ethernet Client
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_FLEXE_CLIENT and SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE == SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_PLUS_1
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_RX_SET_SWITCHOVER,

    /**
     * @brief Trigger a switch-over from primary to backup Flex Ethernet Client
     *
     * validonly SAI_PORT_ATTR_TYPE == SAI_PORT_TYPE_FLEXE_CLIENT and SAI_PORT_ATTR_FLEXE_CLIENT_SWITCHOVER_MODE == SAI_PORT_FLEXE_CLIENT_SWITCHOVER_MODE_1_BY_1
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_FLEXE_CLIENT_TX_SET_SWITCHOVER,

    SAI_PORT_ATTR_EXTENSIONS_RANGE_END

} sai_port_attr_extensions_t;

#endif /* __SAIPORTEXTENSIONS_H_ */
