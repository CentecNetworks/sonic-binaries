/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitypesextensions.h
 *
 * @brief   This module defines type extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITYPESEXTENSIONS_H_
#define __SAITYPESEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief SAI object type extensions
 *
 * @flags free
 */
typedef enum _sai_object_type_extensions_t
{
    SAI_OBJECT_TYPE_EXTENSIONS_RANGE_START = SAI_OBJECT_TYPE_MAX,

    SAI_OBJECT_TYPE_TABLE_BITMAP_CLASSIFICATION_ENTRY = SAI_OBJECT_TYPE_EXTENSIONS_RANGE_START,

    SAI_OBJECT_TYPE_TABLE_BITMAP_ROUTER_ENTRY,

    SAI_OBJECT_TYPE_TABLE_META_TUNNEL_ENTRY,

    SAI_OBJECT_TYPE_FLEXE_GROUP,

    SAI_OBJECT_TYPE_FLEXE_SLOT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT_CROSS_CONNECT,

    SAI_OBJECT_TYPE_TWAMP_SESSION,

    SAI_OBJECT_TYPE_NPM_SESSION,

    SAI_OBJECT_TYPE_ES,

    SAI_OBJECT_TYPE_Y1731_MEG,

    SAI_OBJECT_TYPE_Y1731_SESSION,

    SAI_OBJECT_TYPE_Y1731_REMOTE_MEP,

    SAI_OBJECT_TYPE_PTP_DOMAIN,

    SAI_OBJECT_TYPE_SYNCE,

    SAI_OBJECT_TYPE_MONITOR_BUFFER_MONITOR,

    SAI_OBJECT_TYPE_MONITOR_LATENCY_MONITOR,

    SAI_OBJECT_TYPE_FP,
    /* Add new experimental object types above this line */

    SAI_OBJECT_TYPE_EXTENSIONS_RANGE_END

} sai_object_type_extensions_t;

#endif /* __SAITYPESEXTENSIONS_H_ */

