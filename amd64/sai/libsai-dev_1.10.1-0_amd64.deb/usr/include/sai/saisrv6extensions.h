/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saisrv6extensions.h
 *
 * @brief   This module defines SAI SRV6 extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISRV6EXTENSIONS_H_
#define __SAISRV6EXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief SAI SRV6 attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_srv6_sidlist_attr_extensions_t
{
    SAI_SRV6_SIDLIST_ATTR_EXTENSIONS_RANGE_START = SAI_SRV6_SIDLIST_ATTR_END,

    /**
     * @brief Encapsulate src IP
     *
     * @type sai_ip6_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_SRV6_SIDLIST_ATTR_TYPE == SAI_SRV6_SIDLIST_TYPE_ENCAPS
     */
    SAI_SRV6_SIDLIST_ATTR_ENCAP_SRC_IP = SAI_SRV6_SIDLIST_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Encapsulate IP TTL
     *
     * @type sai_uint8_t
     * @flags CREATE_ONLY
     * @default 255
     * @validonly SAI_SRV6_SIDLIST_ATTR_TYPE == SAI_SRV6_SIDLIST_TYPE_ENCAPS
     */
    SAI_SRV6_SIDLIST_ATTR_ENCAP_TTL_VAL,

    /**
     * @brief Is using reduce mode for encapsulation
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     * @validonly SAI_SRV6_SIDLIST_ATTR_TYPE == SAI_SRV6_SIDLIST_TYPE_ENCAPS
     */
    SAI_SRV6_SIDLIST_ATTR_USE_REDUCE_MODE,

    SAI_SRV6_SIDLIST_ATTR_EXTENSIONS_RANGE_END

} sai_srv6_sidlist_attr_extensions_t;

#endif /* __SAISRV6EXTENSIONS_H_ */
