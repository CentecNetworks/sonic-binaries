/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitypescustom.h
 *
 * @brief   This module defines type custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITYPESCUSTOM_H_
#define __SAITYPESCUSTOM_H_

#include <saitypes.h>

/**
 * @brief SAI object type custom
 *
 * @flags free
 */
typedef enum _sai_object_type_custom_t
{
    SAI_OBJECT_TYPE_CUSTOM_RANGE_START = SAI_OBJECT_TYPE_CUSTOM_RANGE_BASE,

    SAI_OBJECT_TYPE_NPM_SESSION = SAI_OBJECT_TYPE_CUSTOM_RANGE_START,

    SAI_OBJECT_TYPE_ES,

    SAI_OBJECT_TYPE_Y1731_MEG,

    SAI_OBJECT_TYPE_Y1731_SESSION,

    SAI_OBJECT_TYPE_Y1731_REMOTE_MEP,

    SAI_OBJECT_TYPE_PTP_DOMAIN,

    SAI_OBJECT_TYPE_MONITOR_BUFFER_MONITOR,

    SAI_OBJECT_TYPE_MONITOR_LATENCY_MONITOR,

    SAI_OBJECT_TYPE_FLEXE_GROUP,

    SAI_OBJECT_TYPE_FLEXE_SLOT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT,

    SAI_OBJECT_TYPE_FLEXE_CLIENT_CROSS_CONNECT,

    SAI_OBJECT_TYPE_VLAN_CLASS,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_FLOW_FIELD,

    SAI_OBJECT_TYPE_MONITOR_MOX_SESSION_EVENT,

    /* Add new experimental object types above this line */

    SAI_OBJECT_TYPE_CUSTOM_RANGE_END

} sai_object_type_custom_t;

/**
 * @brief Enum defining MPLS out segment type custom
 *
 * @flags free
 */
typedef enum _sai_outseg_type_custom_t
{
    SAI_OUTSEG_TYPE_CUSTOM_START = 0x10000000,

    /** Out segment of last but one node, label stack depth is zero */
    SAI_OUTSEG_TYPE_PHP = SAI_OUTSEG_TYPE_CUSTOM_START,

    SAI_OUTSEG_TYPE_CUSTOM_END

} sai_outseg_type_custom_t;

#endif /* __SAITYPESCUSTOM_H_ */

