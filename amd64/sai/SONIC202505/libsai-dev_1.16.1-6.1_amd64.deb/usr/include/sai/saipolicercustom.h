/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saipolicercustom.h
 *
 * @brief   This module defines SAI QOS Policer interface custom
 */

#ifndef __SAIPOLICERCUSTOM_H_
#define __SAIPOLICERCUSTOM_H_

#include <saipolicer.h>
#include <saitypes.h>

/**
 * @brief Enum defining mode of the policer object custom
 *
 * @flags free
 */
typedef enum _sai_policer_mode_custom_t
{
    SAI_POLICER_MODE_CUSTOM_START = SAI_POLICER_MODE_CUSTOM_RANGE_BASE,

    /** RFC 4115, Two Rate Three color marker, CIR, CBS, PIR and PBS, G, Y and R */
    SAI_POLICER_MODE_ENHANCED_TR_TCM = SAI_POLICER_MODE_CUSTOM_START,

    SAI_POLICER_MODE_CUSTOM_END

} sai_policer_mode_custom_t;

/**
 * @brief Enum defining Policer Attributes custom
 *
 * @flags free
 */
typedef enum _sai_policer_attr_custom_t
{
    /**
     * @brief Enable/disable counter
     *
     * Default disabled. Modify list needs full new set.
     *
     * @type sai_s32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_POLICER_ATTR_ENABLE_COUNTER_LIST = SAI_POLICER_ATTR_CUSTOM_RANGE_START

} sai_policer_attr_custom_t;

#endif /** __SAIPOLICERCUSTOM_H_ */
