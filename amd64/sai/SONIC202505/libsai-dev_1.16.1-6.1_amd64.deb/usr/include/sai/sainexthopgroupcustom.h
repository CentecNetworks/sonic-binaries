/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sainexthopgroupcustom.h
 *
 * @brief   This module defines nexthop group custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAINEXTHOPGROUPCUSTOM_H_
#define __SAINEXTHOPGROUPCUSTOM_H_

#include <sainexthopgroup.h>
#include <saitypes.h>

/**
 * @brief SAI nexthop group attribute custom.
 *
 * @flags free
 */
typedef enum _sai_next_hop_group_attr_custom_t
{
    /**
     * @brief Set PW protect group enable or disable ARP double sending
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_NEXT_HOP_GROUP_ATTR_TYPE == SAI_NEXT_HOP_GROUP_TYPE_PROTECTION
     */
    SAI_NEXT_HOP_GROUP_ATTR_PW_PROTECTION_ARP_DUAL_SENDING = SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Enable hardware switch-over from primary to backup next hop
     *
     * True means switch-over from primary to backup next hop by hardware when primary port is link down.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_NEXT_HOP_GROUP_ATTR_TYPE == SAI_NEXT_HOP_GROUP_TYPE_PROTECTION
     */
    SAI_NEXT_HOP_GROUP_ATTR_HARDWARE_SWITCHOVER_ENABLE

} sai_next_hop_group_attr_custom_t;

/**
 * @brief SAI Next hop group type custom.
 *
 * @flags free
 */
typedef enum _sai_next_hop_group_type_custom_t
{
    SAI_NEXT_HOP_GROUP_TYPE_CUSTOM_START = 0x10000000,

    /** Next hop group is ECMP, with members selected by dynamic loading */
    SAI_NEXT_HOP_GROUP_TYPE_DYNAMIC_LOAD_BALANCE_ECMP = SAI_NEXT_HOP_GROUP_TYPE_CUSTOM_START,

    SAI_NEXT_HOP_GROUP_TYPE_CUSTOM_END

} sai_next_hop_group_type_custom_t;

#endif /* __SAINEXTHOPGROUPCUSTOM_H_ */
