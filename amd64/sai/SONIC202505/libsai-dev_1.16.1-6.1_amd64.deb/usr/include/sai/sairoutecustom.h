/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sairoutecustom.h
 *
 * @brief   This module defines SAI Route Entry interface custom
 */

#ifndef __SAIROUTECUSTOM_H_
#define __SAIROUTECUSTOM_H_

#include <sairoute.h>
#include <saitypes.h>

/**
 * @brief Attribute Id for SAI route object custom
 *
 * @flags free
 */
typedef enum _sai_route_entry_attr_custom_t
{
    /**
     * @brief Route entry is hit, can be read and clear, do not need when create
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_ROUTE_ENTRY_ATTR_HIT_STATUS = SAI_ROUTE_ENTRY_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Enable route entry RPF check
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_ROUTE_ENTRY_ATTR_RPF_CHECK

} sai_route_entry_attr_custom_t;

#endif /** __SAIROUTECUSTOM_H_ */
