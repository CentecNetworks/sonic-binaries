/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiextensions.h
 *
 * @brief   This module defines extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIEXTENSIONS_H_
#define __SAIEXTENSIONS_H_

#include <saitypes.h>

/* existing enum extensions */
#include "saitypesextensions.h"
#include "saiswitchextensions.h"
#include "saiaclextensions.h"
#include "saibfdextensions.h"
#include "saibridgeextensions.h"
#include "saidtelextensions.h"
#include "saifdbextensions.h"
#include "saihostifextensions.h"
#include "sailagextensions.h"
#include "saimplsextensions.h"
#include "sainatextensions.h"
#include "sainexthopextensions.h"
#include "sainexthopgroupextensions.h"
#include "saipolicerextensions.h"
#include "saiportextensions.h"
#include "saiqueueextensions.h"
#include "sairouteextensions.h"
#include "sairouterinterfaceextensions.h"
#include "saischedulergroupextensions.h"
#include "saitunnelextensions.h"
#include "saiudfextensions.h"
#include "saivlanextensions.h"
#include "saisrv6extensions.h"
#include "saimacsecextensions.h"
#include "saischedulerextensions.h"
#include "saibufferextensions.h"

/* new experimental object type includes */
#include "saiexperimentaldashvip.h"
#include "saiexperimentaldashpavalidation.h"
#include "saiexperimentaldashvnet.h"
#include "saiexperimentaldashoutboundrouting.h"
#include "saiexperimentaldashoutboundcatopa.h"
#include "saiexperimentaldashinboundrouting.h"
#include "saiexperimentaldasheni.h"
#include "saiexperimentaldashdirectionlookup.h"
#include "saiexperimentaldashacl.h"
#include "saiexperimentalbmtor.h"
#include "saiexperimentalflexe.h"
#include "saiexperimentales.h"
#include "saiexperimentalptp.h"
#include "saiexperimentalmonitor.h"
#include "saiexperimentaltwamp.h"
#include "saiexperimentaly1731.h"
#include "saiexperimentalsynce.h"
#include "saiexperimentalnpm.h"
#include "saiexperimentalvlanclass.h"

/**
 * @brief Extensions to SAI APIs
 *
 * @flags free
 */
typedef enum _sai_api_extensions_t
{
    SAI_API_EXTENSIONS_RANGE_START = SAI_API_MAX,

    SAI_API_BMTOR = SAI_API_EXTENSIONS_RANGE_START,

    SAI_API_TWAMP,

    SAI_API_NPM,

    SAI_API_ES,

    SAI_API_Y1731,

    SAI_API_PTP,

    SAI_API_SYNCE,

    SAI_API_MONITOR,

    SAI_API_FLEXE,

    SAI_API_VLAN_CLASS,

    SAI_API_DASH_ACL,

    SAI_API_DASH_DIRECTION_LOOKUP,

    SAI_API_DASH_ENI,

    SAI_API_DASH_INBOUND_ROUTING,

    SAI_API_DASH_OUTBOUND_CA_TO_PA,

    SAI_API_DASH_OUTBOUND_ROUTING,

    SAI_API_DASH_VNET,

    SAI_API_DASH_PA_VALIDATION,

    SAI_API_DASH_VIP,

    /* Add new experimental APIs above this line */

    SAI_API_EXTENSIONS_RANGE_END

} sai_api_extensions_t;

#endif /* __SAIEXTENSIONS_H_ */
