/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiaclcustom.h
 *
 * @brief   This module defines SAI ACL custom interface
 */

#ifndef __SAIACLCUSTOM_H_
#define __SAIACLCUSTOM_H_

#include <saiacl.h>
#include <saitypes.h>

/**
 * @brief ACL Action Type custom.
 *
 * @flags free
 */
typedef enum _sai_acl_action_type_custom_t
{
    SAI_ACL_ACTION_TYPE_CUSTOM_START = 0x10000000,

    /** Set Flow Sec SC */
    SAI_ACL_ACTION_TYPE_SET_FLOW_SEC_SC = SAI_ACL_ACTION_TYPE_CUSTOM_START,

    /** Set Security Parameter Identify */
    SAI_ACL_ACTION_TYPE_SET_FLOW_SEC_SPI,

    /** Set MOX session */
    SAI_ACL_ACTION_TYPE_MOX_SESSION_OBJECT,

    /** Set src metadata */
    SAI_ACL_ACTION_TYPE_SET_ACL_SRC_META_DATA,

    /** Set dst metadata */
    SAI_ACL_ACTION_TYPE_SET_ACL_DST_META_DATA,

    /** Disable dynamic load balance forwarding */
    SAI_ACL_ACTION_TYPE_DISABLE_DLB_FORWARDING,

    SAI_ACL_ACTION_TYPE_CUSTOM_END

} sai_acl_action_type_custom_t;

/**
 * @brief Attribute Id for sai_acl_table custom.
 *
 * @flags free
 */
typedef enum _sai_acl_table_attr_custom_t
{
    /**
     * @brief Start of Custom Rule Match Fields
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_START = SAI_ACL_TABLE_ATTR_CUSTOM_RANGE_START + 0x1000,

    /**
     * @brief FDB Src user meta data
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_FDB_SRC_USER_META = SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_START,

    /**
     * @brief Vlan Class user meta data
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_VLAN_CLASS_USER_META,

    /**
     * @brief Dst MAC address match
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_MACDA_HIT,

    /**
     * @brief Src MAC address match
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_MACSA_HIT,

    /**
     * @brief Interface id defined
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_INTERFACE_ID,

    /**
     * @brief Security Parameter Identify
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_FLOWSEC_SPI,

    /**
     * @brief Src Metadata carried from previous ACL Stage
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_ACL_SRC_USER_META,

    /**
     * @brief Dst Metadata carried from previous ACL Stage
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_ACL_DST_USER_META,

    /**
     * @brief Packet is routed.
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_ROUTED_PKT,

    /**
     * @brief Packet Forward Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_PACKET_FORWARD_TYPE,

    /**
     * @brief Discard Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_DISCARD_TYPE,

    /**
     * @brief Src IPv4 Valid bits
     *
     * @type sai_acl_field_data_mask_t sai_ip4_t
     * @flags CREATE_ONLY
     * @default 255.255.255.255
     * @validonly SAI_ACL_TABLE_ATTR_FIELD_SRC_IP == true
     */
    SAI_ACL_TABLE_ATTR_FIELD_VALID_BITS_SRC_IPV4,

    /**
     * @brief Dst IPv4 Valid bits
     *
     * @type sai_acl_field_data_mask_t sai_ip4_t
     * @flags CREATE_ONLY
     * @default 255.255.255.255
     * @validonly SAI_ACL_TABLE_ATTR_FIELD_DST_IP == true
     */
    SAI_ACL_TABLE_ATTR_FIELD_VALID_BITS_DST_IPV4,

    /**
     * @brief End of Custom Rule Match Fields
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_END = SAI_ACL_TABLE_ATTR_FIELD_VALID_BITS_DST_IPV4

} sai_acl_table_attr_custom_t;

/**
 * @brief Attribute Id for sai_acl_entry custom.
 *
 * @flags free
 */
typedef enum _sai_acl_entry_attr_custom_t
{
    /**
     * @brief Start of Custom Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_START = SAI_ACL_ENTRY_ATTR_CUSTOM_RANGE_START + 0x1000,

    /**
     * @brief Src MAC address match user meta data in FDB
     *
     * Value must be in the range defined in
     * #SAI_SWITCH_ATTR_FDB_SRC_USER_META_DATA_RANGE
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_FDB_SRC_USER_META = SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_START,

    /**
     * @brief VLAN Class user meta data
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_VLAN_CLASS_USER_META,

    /**
     * @brief Dst MAC address match
     *
     * @type sai_acl_field_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_MACDA_HIT,

    /**
     * @brief Src MAC address match
     *
     * @type sai_acl_field_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_MACSA_HIT,

    /**
     * @brief Interface id defined
     *
     * @type sai_acl_field_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_ROUTER_INTERFACE
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_INTERFACE_ID,

    /**
     * @brief Security Parameter Identify
     *
     * @type sai_acl_field_data_t sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_FLOWSEC_SPI,

    /**
     * @brief Src Metadata carried from previous ACL stage.
     *
     * When an ACL entry set the meta data, the ACL metadata
     * form previous stages are overridden.
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_SRC_USER_META,

    /**
     * @brief Dst Metadata carried from previous ACL stage.
     *
     * When an ACL entry set the meta data, the ACL metadata
     * form previous stages are overridden.
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_DST_USER_META,

    /**
     * @brief Packet is routed.
     *
     * @type sai_acl_field_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_ROUTED_PKT,

    /**
     * @brief End of Custom Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_END = SAI_ACL_ENTRY_ATTR_FIELD_ROUTED_PKT,

    /**
     * @brief Start of Custom Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_START = SAI_ACL_ENTRY_ATTR_CUSTOM_RANGE_START + 0x2000,

    /**
     * @brief Set Flow Sec SC
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MACSEC_SC
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_FLOW_SEC_SC = SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_START,

    /**
     * @brief Set Security Parameter Identify
     *
     * @type sai_acl_action_data_t sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_FLOW_SEC_SPI,

    /**
     * @brief MOX session
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_MOX_SESSION_OBJECT,

    /**
     * @brief Set src metadata to carry forward to next ACL Stage
     *
     * @type sai_acl_action_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_SRC_META_DATA,

    /**
     * @brief Set dst metadata to carry forward to next ACL Stage
     *
     * @type sai_acl_action_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_DST_META_DATA,

    /**
     * @brief Disable dynamic load balance forwarding for a given match condition
     *
     * @type sai_acl_action_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_DISABLE_DLB_FORWARDING,

    /**
     * @brief End of Custom Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_END = SAI_ACL_ENTRY_ATTR_ACTION_DISABLE_DLB_FORWARDING

} sai_acl_entry_attr_custom_t;

#endif /** __SAIACLCUSTOM_H_ */
