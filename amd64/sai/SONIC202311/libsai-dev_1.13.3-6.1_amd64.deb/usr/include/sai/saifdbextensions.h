/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saifdbextensions.h
 *
 * @brief   This module defines SAI FDB interface extensions
 */

#ifndef __SAIFDBEXTENSIONS_H_
#define __SAIFDBEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Attribute Id for FDB entry extensions
 *
 * @flags free
 */
typedef enum _sai_fdb_entry_attr_extensions_t
{
    SAI_FDB_ENTRY_ATTR_EXTENSIONS_RANGE_START = SAI_FDB_ENTRY_ATTR_END,

    /**
     * @brief Discard the packet when source MAC hit FDB entry
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_FDB_ENTRY_ATTR_SMAC_DROP = SAI_FDB_ENTRY_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Indicates whether the FDB entry is hit
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_FDB_ENTRY_ATTR_HIT_FLAG,

    SAI_FDB_ENTRY_ATTR_EXTENSIONS_RANGE_END

} sai_fdb_entry_attr_extensions_t;

#endif /** __SAIFDBEXTENSIONS_H_ */
