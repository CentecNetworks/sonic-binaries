/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sailagextensions.h
 *
 * @brief   This module defines SAI LAG interface extensions
 */

#ifndef __SAILAGEXTENSIONS_H_
#define __SAILAGEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Attribute data for LAG mode extensions
 */
typedef enum _sai_lag_mode_t
{
    /** LAG member choice mode Static */
    SAI_LAG_MODE_STATIC,

    /** LAG member choice mode fail over */
    SAI_LAG_MODE_STATIC_FAILOVER,

    /** LAG member choice mode Round-Robin */
    SAI_LAG_MODE_RR,

    /** LAG member choice mode Dynamic Load Balance */
    SAI_LAG_MODE_DLB,

    /** LAG member choice mode Resilient Hash */
    SAI_LAG_MODE_RH,

} sai_lag_mode_t;

/**
 * @brief LAG attribute: List of attributes for LAG object extensions
 *
 * @flags free
 */
typedef enum _sai_lag_attr_extensions_t
{
    SAI_LAG_ATTR_EXTENSIONS_RANGE_START = SAI_LAG_ATTR_END,

    /**
     * @brief Member Choice Mode of LAG Group
     *
     * When create LAG group
     * SAI default set member choice mode of LAG group is Static Load Balance if not create with mode
     * Member Choice Mode of LAG Group only can be set during create LAG group, if need to change
     * mode, have to remove LAG group and recreate with the member choice mode you want
     *
     * @type sai_lag_mode_t
     * @flags CREATE_ONLY
     * @default SAI_LAG_MODE_STATIC
     */
    SAI_LAG_ATTR_MODE = SAI_LAG_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Max member of LAG Group could add
     *
     * @type sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan false
     * @default 0
     */
    SAI_LAG_ATTR_CUSTOM_MAX_MEMBER_NUM,

    /**
     * @brief Is customer vlan domain
     *
     * This is a flag which states that the LAG is in customer vlan domain
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_LAG_ATTR_IS_CVLAN_DOMAIN,

    SAI_LAG_ATTR_EXTENSIONS_RANGE_END

} sai_lag_attr_extensions_t;

#endif /** __SAILAGEXTENSIONS_H_ */
