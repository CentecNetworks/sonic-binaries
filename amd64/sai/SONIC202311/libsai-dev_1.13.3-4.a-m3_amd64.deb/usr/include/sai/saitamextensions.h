/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitamextensions.h
 *
 * @brief   This module defines TAM extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITAMEXTENSIONS_H_
#define __SAITAMEXTENSIONS_H_

#include <saitypes.h>

/**
 * @brief Attributes for TAM report
 *
 * @flags free
 */
typedef enum _sai_tam_report_attr_extensions_t
{
    SAI_TAM_REPORT_ATTR_EXTENSIONS_RANGE_START = SAI_TAM_REPORT_ATTR_END,

    SAI_TAM_REPORT_ATTR_EXTENSIONS_RANGE_END

} sai_tam_report_attr_extensions_t;

/**
 * @brief Tam transport Type extensions
 *
 * @flags free
 */
typedef enum _sai_tam_transport_type_extensions_t
{
    SAI_TAM_TRANSPORT_TYPE_EXTENSIONS_RANGE_START = SAI_TAM_TRANSPORT_TYPE_MIRROR + 0x1,

    SAI_TAM_TRANSPORT_TYPE_PORT = SAI_TAM_TRANSPORT_TYPE_EXTENSIONS_RANGE_START,

    SAI_TAM_TRANSPORT_TYPE_EXTENSIONS_RANGE_END
} sai_tam_transport_type_extensions_t;

/**
 * @brief Attributes for TAM transport attribute IDs extensions
 *
 * @flags free
 */
typedef enum _sai_tam_transport_attr_extensions_t
{
    SAI_TAM_TRANSPORT_ATTR_EXTENSIONS_RANGE_START = SAI_TAM_TRANSPORT_ATTR_END,

    /**
     * @brief L2 source MAC address
     *
     * @type sai_mac_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @condition SAI_TAM_TRANSPORT_ATTR_TRANSPORT_TYPE == SAI_TAM_TRANSPORT_TYPE_PORT
     */
    SAI_TAM_TRANSPORT_ATTR_SRC_MAC_ADDRESS = SAI_TAM_TRANSPORT_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief L2 destination MAC address
     *
     * @type sai_mac_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @condition SAI_TAM_TRANSPORT_ATTR_TRANSPORT_TYPE == SAI_TAM_TRANSPORT_TYPE_PORT
     */
    SAI_TAM_TRANSPORT_ATTR_DST_MAC_ADDRESS,

    /**
     * @brief L2 header TPID.
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0x8100
     */
    SAI_TAM_TRANSPORT_ATTR_VLAN_TPID,

    /**
     * @brief L2 header VLAN Id.
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan true
     * @default 0
     */
    SAI_TAM_TRANSPORT_ATTR_VLAN_ID,

    /**
     * @brief L2 header packet priority (3 bits).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_TRANSPORT_ATTR_VLAN_PRI,

    /**
     * @brief L2 header Vlan CFI (1 bit).
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_TRANSPORT_ATTR_VLAN_CFI,

    SAI_TAM_TRANSPORT_ATTR_EXTENSIONS_RANGE_END

} sai_tam_transport_attr_extensions_t;

/**
 * @brief Attributes for TAM int attribute IDs extensions
 *
 * @flags free
 */
typedef enum _sai_tam_int_attr_extensions_t
{
    SAI_TAM_INT_ATTR_EXTENSIONS_RANGE_START = SAI_TAM_INT_ATTR_END,

    /**
     * @brief Tam report type
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_REPORT
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_INT_ATTR_EXTENSIONS_REPORT_ID = SAI_TAM_INT_ATTR_EXTENSIONS_RANGE_START,

    SAI_TAM_INT_ATTR_EXTENSIONS_RANGE_END

} sai_tam_int_attr_extensions_t;

/**
 * @brief Attributes for TAM telemetry attribute IDs extensions
 *
 * @flags free
 */
typedef enum _sai_tam_telemetry_attr_extensions_t
{
    SAI_TAM_TELEMETRY_ATTR_EXTENSIONS_RANGE_START = SAI_TAM_TELEMETRY_ATTR_END,

    /**
     * @brief Collector object list
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_COLLECTOR
     * @default empty
     */
    SAI_TAM_TELEMETRY_ATTR_EXTENSIONS_COLLECTOR_LIST = SAI_TAM_TELEMETRY_ATTR_EXTENSIONS_RANGE_START,

    SAI_TAM_TELEMETRY_ATTR_EXTENSIONS_RANGE_END

} sai_tam_telemetry_attr_extensions_t;

/**
 * @brief Tam event Type extensions
 *
 * @flags free
 */
typedef enum _sai_tam_event_type_extensions_t
{
    SAI_TAM_EVENT_TYPE_EXTENSIONS_RANGE_START = SAI_TAM_EVENT_TYPE_BSP + 0x1,

    /**
     * @brief Packet drop event
     * State aware drop monitoring of packets
     */
    SAI_TAM_EVENT_TYPE_PACKET_DROP_STATEFUL = SAI_TAM_EVENT_TYPE_EXTENSIONS_RANGE_START,

    /**
     * @brief Flow latency monitoring event
     */
    SAI_TAM_EVENT_TYPE_FLOW_LATENCY,

    /**
     * @brief Device Buffer threshold event
     */
    SAI_TAM_EVENT_TYPE_DEVICE_THRESHOLD,

    /**
     * @brief Unicast Buffer service pool threshold event
     */
    SAI_TAM_EVENT_TYPE_BSP_UCAST,

    /**
     * @brief Multicast Buffer service pool threshold event
     */
    SAI_TAM_EVENT_TYPE_BSP_MCAST,

    SAI_TAM_EVENT_TYPE_EXTENSIONS_RANGE_END

} sai_tam_event_type_extensions_t;

/**
 * @brief Attributes for TAM event attribute IDs extensions
 *
 * @flags free
 */
typedef enum _sai_tam_event_attr_extensions_t
{
    SAI_TAM_EVENT_ATTR_EXTENSIONS_RANGE_START = SAI_TAM_EVENT_ATTR_END,

    /**
     * @brief Aging interval (in milliseconds) for an event
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_EVENT_ATTR_AGING_INTERVAL = SAI_TAM_EVENT_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Enable/Disable Samplepacket session
     *
     * Enable ingress sampling by assigning samplepacket object id Disable
     * ingress sampling by assigning #SAI_NULL_OBJECT_ID as attribute value.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_SAMPLEPACKET
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_EVENT_ATTR_INGRESS_SAMPLEPACKET_ENABLE,

    /**
     * @brief Device Identifier
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_EVENT_ATTR_DEVICE_ID,

    /**
     * @brief Event Identifier
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_EVENT_ATTR_EVENT_ID,

    /**
     * @brief Collector Object list
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_COLLECTOR
     * @default empty
     */
    SAI_TAM_EVENT_ATTR_EXTENSIONS_COLLECTOR_LIST,

    /**
     * @brief Type of ingress packet drops
     *
     * @type sai_s32_list_t sai_packet_drop_type_ingress_t
     * @flags CREATE_AND_SET
     * @default empty
     * @validonly SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP or SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP_STATEFUL
     */
    SAI_TAM_EVENT_ATTR_PACKET_DROP_TYPE_INGRESS,

    /**
     * @brief Type of MMU packet drops
     *
     * @type sai_s32_list_t sai_packet_drop_type_mmu_t
     * @flags CREATE_AND_SET
     * @default empty
     * @validonly SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP or SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP_STATEFUL
     */
    SAI_TAM_EVENT_ATTR_PACKET_DROP_TYPE_MMU,

    /**
     * @brief Type of egress packet drops
     *
     * @type sai_s32_list_t sai_packet_drop_type_egress_t
     * @flags CREATE_AND_SET
     * @default empty
     * @validonly SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP or SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_PACKET_DROP_STATEFUL
     */
    SAI_TAM_EVENT_ATTR_PACKET_DROP_TYPE_EGRESS,

    /**
     * @brief Sample rate
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TAM_EVENT_ATTR_SAMPLE_RATE,

    /**
     * @brief User meta data
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_TAM_EVENT_ATTR_USER_META_DATA,

    SAI_TAM_EVENT_ATTR_EXTENSIONS_RANGE_END
} sai_tam_event_attr_extensions_t;

/**
 * @brief TAM Packet Ingress Drop Types
 */
typedef enum _sai_packet_drop_type_ingress_t
{
    /** None */
    SAI_PACKET_DROP_TYPE_INGRESS_NONE,

    /** ALL */
    SAI_PACKET_DROP_TYPE_INGRESS_ALL,

    /** Flags drops */
    SAI_PACKET_DROP_TYPE_INGRESS_CML_FLAGS_DROP,

    /** Layer 2 source static move drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L2_SRC_STATIC_MOVE,

    /** Layer 2 discard drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L2_SRC_DISCARD,

    /** MAC multicast drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MACSA_MULTICAST,

    /** TPID check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_OUTER_TPID_CHECK_FAILED,

    /** Port vlan check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_INCOMING_PVLAN_CHECK_FAILED,

    /** Packet integrity check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_PKT_INTEGRITY_CHECK_FAILED,

    /** Unknown protocol drops */
    SAI_PACKET_DROP_TYPE_INGRESS_PROTOCOL_PKT_DROP,

    /** VLAN membership check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MEMBERSHIP_CHECK_FAILED,

    /** Spanning tree check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_SPANNING_TREE_CHECK_FAILED,

    /** Layer 2 destination lookup miss drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L2_DST_LOOKUP_MISS,

    /** Layer 2 destination discard drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L2_DST_DISCARD,

    /** Layer 3 destination lookup miss drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_DST_LOOKUP_MISS,

    /** Layer 3 destination discard drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_DST_DISCARD,

    /** Layer 3 header error drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_HDR_ERROR,

    /** Layer 3 IP TTL error drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_TTL_ERROR,

    /** RPF check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_IPMC_L3_IIF_OR_RPA_ID_CHECK_FAILED,

    /** Tunnel TTL check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_TUNNEL_TTL_CHECK_FAILED,

    /** Invalid tunnel object drops */
    SAI_PACKET_DROP_TYPE_INGRESS_TUNNEL_OBJECT_VALIDATION_FAILED,

    /** Invalid tunnel adaptation drops */
    SAI_PACKET_DROP_TYPE_INGRESS_TUNNEL_ADAPT_DROP,

    /** Port VLAN drops */
    SAI_PACKET_DROP_TYPE_INGRESS_PVLAN_DROP,

    /** Filter drops */
    SAI_PACKET_DROP_TYPE_INGRESS_VFP,

    /** Filter drops */
    SAI_PACKET_DROP_TYPE_INGRESS_IFP,

    /** Filter based metering drops */
    SAI_PACKET_DROP_TYPE_INGRESS_IFP_METER,

    /** Destination filter drops */
    SAI_PACKET_DROP_TYPE_INGRESS_DST_FP,

    /** MPLS protection drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_PROTECTION_DROP,

    /** Invalid MPLS label action drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_LABEL_ACTION_INVALID,

    /** MPLS termination table drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_TERM_POLICY_SELECT_TABLE_DROP,

    /** MPLS reserved label drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_RESERVED_LABEL_EXPOSED,

    /** MPLS TTL error drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_TTL_ERROR,

    /** MPLS ECN drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_ECN_ERROR,

    /** Exact match table drops */
    SAI_PACKET_DROP_TYPE_INGRESS_EM_FT,

    /** VLAN translation table drops */
    SAI_PACKET_DROP_TYPE_INGRESS_IVXLT,

    /** Re-circulation mirror drops */
    SAI_PACKET_DROP_TYPE_INGRESS_EP_RECIRC_MIRROR_DROP,

    /** IPv4 gateway drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MTOP_IPV4_GATEWAY,

    /** Reverse RPF check drops */
    SAI_PACKET_DROP_TYPE_INGRESS_URPF_CHECK_FAILED,

    /** Source port knockout drops */
    SAI_PACKET_DROP_TYPE_INGRESS_SRC_PORT_KNOCKOUT_DROP,

    /** LAG fail over port down drops */
    SAI_PACKET_DROP_TYPE_INGRESS_LAG_FAILOVER_PORT_DOWN,

    /** Split horizon check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_SPLIT_HORIZON_CHECK_FAILED,

    /** Destination link down drops */
    SAI_PACKET_DROP_TYPE_INGRESS_DST_LINK_DOWN,

    /** Port block mask drops */
    SAI_PACKET_DROP_TYPE_INGRESS_BLOCK_MASK_DROP,

    /** Layer 3 MTU check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_MTU_CHECK_FAILED,

    /** Sequence number check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_SEQ_NUM_CHECK_FAILED,

    /** Ingress interface same as egress interface drops */
    SAI_PACKET_DROP_TYPE_INGRESS_L3_IIF_EQ_L3_OIF,

    /** Storm control drops */
    SAI_PACKET_DROP_TYPE_INGRESS_STORM_CONTROL_DROP,

    /** Membership check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_EGR_MEMBERSHIP_CHECK_FAILED,

    /** Spanning tree check fail drops */
    SAI_PACKET_DROP_TYPE_INGRESS_EGR_SPANNING_TREE_CHECK_FAILED,

    /** Port block mode drops */
    SAI_PACKET_DROP_TYPE_INGRESS_DST_PBM_ZERO,

    /** MPLS control packet drops */
    SAI_PACKET_DROP_TYPE_INGRESS_MPLS_CTRL_PKT_DROP

} sai_packet_drop_type_ingress_t;

/**
 * @brief TAM Packet MMU Drop Types
 */
typedef enum _sai_packet_drop_type_mmu_t
{
    /** None */
    SAI_PACKET_DROP_TYPE_MMU_NONE,

    /** ALL */
    SAI_PACKET_DROP_TYPE_MMU_ALL,

    /** Port group limit */
    SAI_PACKET_DROP_TYPE_MMU_ING_PG_LIMIT,

    /** Ingress port service pool limit */
    SAI_PACKET_DROP_TYPE_MMU_ING_PORTSP_LIMIT,

    /** Headroom pool limit */
    SAI_PACKET_DROP_TYPE_MMU_ING_HEADROOM_POOL_LIMIT,

    /** Egress queue limit */
    SAI_PACKET_DROP_TYPE_MMU_EGR_QUEUE_LIMIT,

    /** Egress port service pool limit */
    SAI_PACKET_DROP_TYPE_MMU_EGR_PORTSP_LIMIT,

    /** WRED check */
    SAI_PACKET_DROP_TYPE_MMU_WRED_CHECKS

} sai_packet_drop_type_mmu_t;

/**
 * @brief TAM Packet Egress Drop Types
 */
typedef enum _sai_packet_drop_type_egress_t
{
    /** None */
    SAI_PACKET_DROP_TYPE_EGRESS_NONE,

    /** ALL */
    SAI_PACKET_DROP_TYPE_EGRESS_ALL,

    /** Layer 2 output interface drops */
    SAI_PACKET_DROP_TYPE_EGRESS_L2_OIF,

    /** Membership drops */
    SAI_PACKET_DROP_TYPE_EGRESS_MEMBERSHIP,

    /** Membership drops */
    SAI_PACKET_DROP_TYPE_EGRESS_DVP_MEMBERSHIP,

    /** TTL check drops */
    SAI_PACKET_DROP_TYPE_EGRESS_TTL,

    /** Layer 3 same interface drops */
    SAI_PACKET_DROP_TYPE_EGRESS_L3_SAME_INTF,

    /** Layer 2 same interface drops */
    SAI_PACKET_DROP_TYPE_EGRESS_L2_SAME_PORT,

    /** Split horizon drops */
    SAI_PACKET_DROP_TYPE_EGRESS_SPLIT_HORIZON,

    /** Spanning tree disabled drops */
    SAI_PACKET_DROP_TYPE_EGRESS_STG_DISABLE,

    /** Spanning tree blocked drops */
    SAI_PACKET_DROP_TYPE_EGRESS_STG_BLOCK,

    /** Filter drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EFP,

    /** Metering drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EGR_METER,

    /** MTU check drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EGR_MTU,

    /** VLAN translation table drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EGR_VXLT,

    /** Cell size large drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EGR_CELL_TOO_LARGE,

    /** Cell size small drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EGR_CELL_TOO_SMALL,

    /** QOS remarking drops */
    SAI_PACKET_DROP_TYPE_EGRESS_QOS_REMARKING,

    /** Same membership drops */
    SAI_PACKET_DROP_TYPE_EGRESS_SVP_EQUAL_DVP,

    /** Invalid 1588 packet drops */
    SAI_PACKET_DROP_TYPE_EGRESS_INVALID_1588_PKT,

    /** Flex edit drops */
    SAI_PACKET_DROP_TYPE_EGRESS_FLEX_EDITOR,

    /** Egress re-circulation drops */
    SAI_PACKET_DROP_TYPE_EGRESS_EP_RECIRC,

    /** IFA metadata delete drops */
    SAI_PACKET_DROP_TYPE_EGRESS_IFA_MD_DELETE

} sai_packet_drop_type_egress_t;

#endif /* __SAITAMEXTENSIONS_H_ */

