/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saivlanextensions.h
 *
 * @brief   This module defines vlan extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIVLANEXTENSIONS_H_
#define __SAIVLANEXTENSIONS_H_

#include <sai.h>

/**
 * @brief SAI vlan attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_vlan_attr_extensions_t
{
    SAI_VLAN_ATTR_EXTENSIONS_RANGE_START = SAI_VLAN_ATTR_END,

    /**
     * @brief Set vlan domain id, and so far, only one domain is supported, the value cannot be 0
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_PTP_DOMAIN
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_VLAN_ATTR_PTP_DOMAIN_ID = SAI_VLAN_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Vlan packet stats enable or disable control for VLAN
     *
     * Packet stats control for VLAN. Default is
     * enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_VLAN_ATTR_CUSTOM_STATS_ENABLE,

    /**
     * @brief Attach/Detach policer to vlan
     *
     * Set policer id = #SAI_NULL_OBJECT_ID to disable policer on vlan.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_POLICER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_VLAN_ATTR_POLICER_ID,

    /**
     * @brief DHCP packet action for VLAN
     *
     * Overrides DHCP packet action on port.
     *
     * @type sai_packet_action_t
     * @flags CREATE_AND_SET
     * @default SAI_PACKET_ACTION_LOG
     */
    SAI_VLAN_ATTR_DHCP_PACKET_ACTION,

    /**
     * @brief DHCPV6 packet action for VLAN
     *
     * Overrides DHCPV6 packet action on port.
     *
     * @type sai_packet_action_t
     * @flags CREATE_AND_SET
     * @default SAI_PACKET_ACTION_LOG
     */
    SAI_VLAN_ATTR_DHCPV6_PACKET_ACTION,

    /**
     * @brief ARP packet action for VLAN
     *
     * @type sai_packet_action_t
     * @flags CREATE_AND_SET
     * @default SAI_PACKET_ACTION_TRANSIT
     */
    SAI_VLAN_ATTR_ARP_PACKET_ACTION,

    SAI_VLAN_ATTR_EXTENSIONS_RANGE_END

} sai_vlan_attr_extensions_t;

#endif /* __SAIVLANEXTENSIONS_H_ */
