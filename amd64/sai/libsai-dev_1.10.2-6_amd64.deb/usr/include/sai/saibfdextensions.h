/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saibfdextensions.h
 *
 * @brief   This module defines BFD extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIBFDEXTENSIONS_H_
#define __SAIBFDEXTENSIONS_H_

#include <sai.h>

#define SAI_BFD_CV_SIZE 32

/**
 * @brief SAI type of encapsulation for BFD
 *
 * @flags free
 */
typedef enum _sai_bfd_encapsulation_type_extensions_t
{
    SAI_BFD_ENCAPSULATION_TYPE_EXTENSIONS_START = SAI_BFD_ENCAPSULATION_TYPE_NONE,

    /**
     * @brief MPLS Encapsulation | L2 Ethernet header | MPLS header (| Associated Channel Header) (| IP header | UDP header) | Original BFD packet
     */
    SAI_BFD_ENCAPSULATION_TYPE_MPLS,

    /**
     * @brief Seamless Initiator Mode for MPLS
     */
    SAI_BFD_ENCAPSULATION_TYPE_SEAMLESS_INITIATOR_MPLS,

    /**
     * @brief Seamless Reflector Mode for MPLS
     */
    SAI_BFD_ENCAPSULATION_TYPE_SEAMLESS_REFLECTOR_MPLS,

    /**
     * @brief Seamless Initiator Mode for IP
     */
    SAI_BFD_ENCAPSULATION_TYPE_SEAMLESS_INITIATOR_IP,

    /**
     * @brief Seamless Reflector Mode
     */
    SAI_BFD_ENCAPSULATION_TYPE_SEAMLESS_REFLECTOR_IP,

    /**
     * @brief Seamless Initiator Mode for Segment Rouging IPv6
     */
    SAI_BFD_ENCAPSULATION_TYPE_SEAMLESS_INITIATOR_SRV6,

    SAI_BFD_ENCAPSULATION_TYPE_EXTENSIONS_END

} sai_bfd_encapsulation_type_extensions_t;

/**
 * @brief SAI type of MPLS encapsulated BFD
 */
typedef enum _sai_bfd_mpls_type_t
{
    /** Normal MPLS BFD, include Label Switched Path/Pseudo wire */
    SAI_BFD_MPLS_TYPE_NORMAL,

    /** MPLS transport BFD */
    SAI_BFD_MPLS_TYPE_TP,

} sai_bfd_mpls_type_t;

/**
 * @brief Defines the Associated Channel Header channel type of BFD encapsulation
 */
typedef enum _sai_bfd_ach_channel_type_t
{
    /** BFD Associated Channel Header channel type without IP/UDP Associated Channel Header Type = 0x0007 */
    SAI_BFD_ACH_CHANNEL_TYPE_VCCV_RAW,

    /** BFD Associated Channel Header channel type with IPv4/UDP Associated Channel Header Type = 0x0021 */
    SAI_BFD_ACH_CHANNEL_TYPE_VCCV_IPV4,

    /** BFD Associated Channel Header channel type with IPv6/UDP Associated Channel Header Type = 0x0057 */
    SAI_BFD_ACH_CHANNEL_TYPE_VCCV_IPV6,

    /** BFD Associated Channel Header channel type MPLS transport CC Associated Channel Header Type = 0x0022, CV Associated Channel Header Type = 0x0023 */
    SAI_BFD_ACH_CHANNEL_TYPE_TP,

} sai_bfd_ach_channel_type_t;

/**
 * @brief SAI BFD session attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_bfd_session_attr_extensions_t
{
    SAI_BFD_SESSION_ATTR_EXTENSIONS_RANGE_START = SAI_BFD_SESSION_ATTR_END,

    /**
     * @brief BFD Session remote state
     *
     * @type sai_bfd_session_state_t
     * @flags READ_ONLY
     */
    SAI_BFD_SESSION_ATTR_REMOTE_STATE = SAI_BFD_SESSION_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief MPLS encapsulated BFD type
     *
     * @type sai_bfd_mpls_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE == SAI_BFD_ENCAPSULATION_TYPE_MPLS
     */
    SAI_BFD_SESSION_ATTR_BFD_MPLS_TYPE,

    /**
     * @brief BFD Associated Channel Header valid
     *
     * @type bool
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE == SAI_BFD_ENCAPSULATION_TYPE_MPLS
     */
    SAI_BFD_SESSION_ATTR_ACH_HEADER_VALID,

    /**
     * @brief BFD Associated Channel Header channel type
     *
     * @type sai_bfd_ach_channel_type_t
     * @flags CREATE_ONLY
     * @default SAI_BFD_ACH_CHANNEL_TYPE_TP
     */
    SAI_BFD_SESSION_ATTR_BFD_ACH_CHANNEL_TYPE,

    /**
     * @brief MPLS label bind to BFD session
     *
     * @type sai_uint32_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE == SAI_BFD_ENCAPSULATION_TYPE_MPLS
     */
    SAI_BFD_SESSION_ATTR_MPLS_IN_LABEL,

    /**
     * @brief Transmit MPLS label TTL
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 255
     * @validonly SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE == SAI_BFD_ENCAPSULATION_TYPE_MPLS
     */
    SAI_BFD_SESSION_ATTR_MPLS_TTL,

    /**
     * @brief Transmit MPLS label exp
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_BFD_SESSION_ATTR_BFD_ENCAPSULATION_TYPE == SAI_BFD_ENCAPSULATION_TYPE_MPLS
     */
    SAI_BFD_SESSION_ATTR_MPLS_EXP,

    /**
     * @brief MPLS transport BFD CV enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BFD_SESSION_ATTR_TP_CV_ENABLE,

    /**
     * @brief MPLS transport BFD CV Source Maintenance End Point-ID char[SAI_BFD_CV_SIZE]
     *
     * @type char
     * @flags CREATE_AND_SET
     * @default ""
     */
    SAI_BFD_SESSION_ATTR_TP_CV_SRC_MEP_ID,

    /**
     * @brief MPLS transport BFD section OAM router interface id
     *
     * @type sai_object_id_t
     * @flags CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_ROUTER_INTERFACE
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BFD_SESSION_ATTR_TP_ROUTER_INTERFACE_ID,

    /**
     * @brief MPLS transport BFD without gal, by default, BFD for Label Switched Path with gal, BFD for Pseudo wire without gal
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_BFD_SESSION_ATTR_TP_WITHOUT_GAL,

    /**
     * @brief The next hop id
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP, SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BFD_SESSION_ATTR_NEXT_HOP_ID,

    /**
     * @brief The HW protection next hop group id
     * only for SAI_NEXT_HOP_GROUP_TYPE_PROTECTION, used for hardware protection switch
     * SAI_NULL_OBJECT_ID to disable
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BFD_SESSION_ATTR_HW_PROTECTION_NEXT_HOP_GROUP_ID,

    /**
     * @brief Indicate the path BFD session monitored is protecting path or working path
     * used when SAI_BFD_SESSION_ATTR_HW_PROTECTION_NEXT_HOP_GROUP_ID is not SAI_NULL_OBJECT_ID
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BFD_SESSION_ATTR_HW_PROTECTION_IS_PROTECTION_PATH,

    /**
     * @brief Indicate the BFD session HW protection is enabled or not
     * used when SAI_BFD_SESSION_ATTR_HW_PROTECTION_NEXT_HOP_GROUP_ID is not SAI_NULL_OBJECT_ID
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BFD_SESSION_ATTR_HW_PROTECTION_EN,

    SAI_BFD_SESSION_ATTR_EXTENSIONS_RANGE_END

} sai_bfd_session_attr_extensions_t;

#endif /* __SAIBFDEXTENSIONS_H_ */
