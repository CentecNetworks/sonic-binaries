/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiipmcextensions.h
 *
 * @brief   This module defines SAI IPMC interface extensions
 */

#ifndef __SAIIPMCEXTENSIONS_H_
#define __SAIIPMCEXTENSIONS_H_

#include <sai.h>

/**
 * @brief  Extension Attribute Id for IPMC entry
 *
 * @flags free
 */
typedef enum _sai_ipmc_entry_attr_extensions_t
{
    SAI_IPMC_ENTRY_ATTR_EXTENSIONS_RANGE_START = SAI_IPMC_ENTRY_ATTR_END,

    /**
     * @brief Attach a counter
     *
     * When it is empty, then packet hits won't be counted
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_COUNTER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_IPMC_ENTRY_ATTR_COUNTER_ID = SAI_IPMC_ENTRY_ATTR_EXTENSIONS_RANGE_START,

    SAI_IPMC_ENTRY_ATTR_EXTENSIONS_RANGE_END

} sai_ipmc_entry_attr_extensions_t;

#endif /** __SAIIPMCEXTENSIONS_H_ */

