/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sainexthopextensions.h
 *
 * @brief   This module defines nexthop extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAINEXTHOPEXTENSIONS_H_
#define __SAINEXTHOPEXTENSIONS_H_

#include <sai.h>

/**
 * @brief SAI nexthop attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_next_hop_attr_extensions_t
{
    SAI_NEXT_HOP_ATTR_EXTENSIONS_RANGE_START = SAI_NEXT_HOP_ATTR_END,

    /**
     * @brief Next hop entry tunnel-id for MPLS PUSH
     *
     * valid when SAI_NEXT_HOP_ATTR_TYPE == SAI_NEXT_HOP_TYPE_MPLS or ( SAI_NEXT_HOP_ATTR_TYPE == SAI_NEXT_HOP_TYPE_TUNNEL_ENCAP and SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2)
     *
     * @type sai_object_id_t
     * @flags CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_TUNNEL
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_NEXT_HOP_ATTR_MPLS_ENCAP_TUNNEL_ID = SAI_NEXT_HOP_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Next hop id
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_NEXT_HOP, SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_NEXT_HOP_ATTR_NEXT_LEVEL_NEXT_HOP_ID,

    /**
     * @brief Service id for next hop
     *
     * used for H-QOS, set to service schedule group service id
     * set to 0 means disable H-QOS on next hop
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     * @validonly SAI_NEXT_HOP_ATTR_TYPE == SAI_NEXT_HOP_TYPE_TUNNEL_ENCAP
     */
    SAI_NEXT_HOP_ATTR_SERVICE_ID,

    /**
     * @brief MPLS next hop is segment route or not
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     * @validonly SAI_NEXT_HOP_ATTR_TYPE == SAI_NEXT_HOP_TYPE_MPLS
     */
    SAI_NEXT_HOP_ATTR_IS_SR,

    SAI_NEXT_HOP_ATTR_EXTENSIONS_RANGE_END

} sai_next_hop_attr_extensions_t;

#endif /* __SAINEXTHOPEXTENSIONS_H_ */
