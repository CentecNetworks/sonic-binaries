/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiswitchextensions.h
 *
 * @brief   This module defines switch extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISWITCHEXTENSIONS_H_
#define __SAISWITCHEXTENSIONS_H_

#include <saiswitch.h>
#include <saitypes.h>

#define SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE 0x13

/**
 * @brief SAI switch attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_switch_attr_extensions_t
{
    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START = SAI_SWITCH_ATTR_END,

    /**
     * @brief Set Switch Y1731 session event notification callback function passed to the adapter.
     *
     * Use sai_y1731_session_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_y1731_session_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_Y1731_SESSION_STATE_CHANGE_NOTIFY = SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Number of Y1731 session in the NPU
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_NUMBER_OF_Y1731_SESSION,

    /**
     * @brief Max number of Y1731 session NPU supports
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_MAX_Y1731_SESSION,

    /**
     * @brief List of Y1731 session performance monitor offloads supported in the ASIC
     *
     * @type sai_s32_list_t sai_y1731_session_perf_monitor_offload_type_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_SUPPORTED_Y1731_SESSION_PERF_MONITOR_OFFLOAD_TYPE,

    /**
     * @brief Apply ECN action for ECT traffic.
     * Attribute controls whether do ECN modification when traffic beyond
     * the ECN threshold.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_ECN_ACTION_ENABLE,

    /**
     * @brief Buffer monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_buffer_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_buffer_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_NOTIFY,

    /**
     * @brief Latency monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_latency_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_latency_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_NOTIFY,

    /**
     * @brief Buffer monitor microburst enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_ENABLE,

    /**
     * @brief Define the min threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MIN_THRD,

    /**
     * @brief Define the max threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MAX_THRD,

    /**
     * @brief Send the packet to CPU when the usage of buffer over the threshold
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_OVERTHRD_EVENT,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond) for the duration of microburst
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_LEVEL_THRESHOLD,

    /**
     * @brief Enable the ingress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor based on queue, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_QUEUE_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief The buffer monitor time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_TIME_INTERVAL,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_WATERMARK,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_WATERMARK,

    /**
     * @brief Define the min latency threshold(unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MIN_THRESHOLD,

    /**
     * @brief Define the max latency threshold (unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MAX_THRESHOLD,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond)
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_LEVEL_THRESHOLD,

    /**
     * @brief Set the latency monitor scan time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_INTERVAL,

    /**
     * @brief Set signal degrade event notification callback function passed to the adapter.
     *
     * Use sai_signal_degrade_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_signal_degrade_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_SIGNAL_DEGRADE_EVENT_NOTIFY,

    /**
     * @brief Set PTP packet tx event notification callback function passed to the adapter.
     *
     * Use sai_packet_event_ptp_tx_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_packet_event_ptp_tx_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_PACKET_EVENT_PTP_TX_NOTIFY,

    /**
     * @brief Flex Ethernet Group Event notification callback function passed to the adapter.
     *
     * Use sai_flexe_group_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_NOTIFY,

    /**
     * @brief Flex Ethernet Group Event State change notification callback function passed to the adapter.
     *
     * Use sai_flexe_event_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_STATE_CHANGE_NOTIFY,

    /**
     * @brief FDB SRC user-based meta data range
     *
     * @type sai_u32_range_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_FDB_SRC_USER_META_DATA_RANGE,

    /**
     * @brief MOX session notification callback function passed to the adapter.
     *
     * Use sai_monitor_mox_session_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_mox_session_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_NOTIFY,

    /**
     * @brief MOX session flow aging time(s).
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FLOW_AGING_TIME,

    /**
     * @brief MOX session new flow first packet export enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FIRST_PACKET_EXPORT_ENABLE,

    /**
     * @brief MOX session export interval(ms).
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 100
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_EXPORT_INTERVAL,

    /**
     * @brief MOX session drop packet number threshold
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 512
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_DROP_PACKET_NUM_THRESHOLD,

    /**
     * @brief Default SAI ACL type user define trap
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP
     * @default internal
     * @range SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE
     */
    SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MIN,

    /**
     * @brief Default SAI ACL type user define trap
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP
     * @default internal
     */
    SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MAX = SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MIN + SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE,

    /**
     * @brief ECMP resilient hash enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_ECMP_RESILIENT_HASH,

    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_END

} sai_switch_attr_extensions_t;

#endif /* __SAISWITCHEXTENSIONS_H_ */
