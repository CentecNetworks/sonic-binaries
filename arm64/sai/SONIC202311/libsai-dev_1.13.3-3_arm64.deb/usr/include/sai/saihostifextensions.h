/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saihostifextensions.h
 *
 * @brief   This module defines SAI host interface extensions
 *
 * @par Abstract
 *
 *    This module defines SAI Host Interface which is responsible for
 *    creating/deleting Linux netdev corresponding to the host interface type.
 *    All the management operations of the netdevs such as changing IP address
 *    are outside the scope of SAI.
 */

#ifndef __SAIHOSTIFEXTENSIONS_H_
#define __SAIHOSTIFEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Host interface trap type extensions
 *
 * @flags free
 */
typedef enum _sai_hostif_trap_type_extensions_t
{
    SAI_HOSTIF_TRAP_TYPE_EXTENSIONS_RANGE_START = SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_RANGE_BASE,

    /**
     * @brief Y1731 1-way Delay Measurement/Delay Measurement Reply to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_DM = SAI_HOSTIF_TRAP_TYPE_EXTENSIONS_RANGE_START,

    /**
     * @brief Y1731 link trace to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_LT,

    /**
     * @brief Y1731 Loopback Reply Message to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_LBR,

    /**
     * @brief Y1731 Loss Measurement Reply to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_LMR,

    /**
     * @brief Y1731 MPLS Transport Loopback Message CV check fail send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_TP_CV_FAIL,

    /**
     * @brief Y1731 Automatic Protection Switching to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_APS,

    /**
     * @brief Y1731 MPLS Transport Direct Loss Measurement to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_TP_DLM,

    /**
     * @brief Y1731 MPLS Transport Delay Measurement/Direct Loss and Delay Measurement to local switch send to CPU
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_Y1731_TP_DM,

    /**
     * @brief Log all packet to CPU when micro burst occur
     * (default packet action is SAI_PACKET_ACTION_COPY)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_MICROBURST_LOG,

    /**
     * @brief Log packet to CPU when latency over the threshold
     * (default packet action is SAI_PACKET_ACTION_COPY)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_LATENCY_OVERFLOW_LOG,

    /**
     * @brief Traffic with destination MAC is 0180.c200.0014 or 0180.c200.0015 for broadcast,
     * or 0900.2b00.0004 or 0900.2b00.0005 for p2p usage.
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_ISIS,

    /**
     * @brief LSP ping, IP 127/8, UDP destination port 3503, label decap.
     * (default packet action is SAI_PACKET_ACTION_TRAP)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_LSP_PING,

    /**
     * @brief Loop detect, with destination MAC is ffff.ffff.ffff, and ether net type is 39134.
     * When STP port state is block, it will forward as normal packet.
     * (default packet action is SAI_PACKET_ACTION_TRAP)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_LOOPDETECT,

    /**
     * @brief RADIUS traffic (UDP src port == 1812 or UDP src port == 1813 or UDP src port == 1645 or UDP src port == 1646)
     * (default packet action is forward)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_RADIUS,

    /**
     * @brief Terminal Access Controller Access-Control System plus traffic (TCP src port == 49)
     * (default packet action is forward)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_TACACS_PLUS,

    /**
     * @brief BFD learning packet, with your disc set to 0, send to CPU
     * (default packet action is trap)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_EXCEPTION_BFD_LEARNING,

    /**
     * @brief Multi-chassis LAG control traffic (TCP src port == 8888 or TCP dst port == 8888)
     * to local router IP address (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_MLAG_CONTROL,

    /**
     * @brief Multi-Active Detection traffic (UDP dst port == 8888)
     * to local router IP address (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_MAD,

    SAI_HOSTIF_TRAP_TYPE_GLOBAL_DROP_INGRESS_RED,

    SAI_HOSTIF_TRAP_TYPE_GLOBAL_DROP_INGRESS_YELLOW,

    SAI_HOSTIF_TRAP_TYPE_GLOBAL_DROP_EGRESS_RED,

    SAI_HOSTIF_TRAP_TYPE_GLOBAL_DROP_EGRESS_YELLOW,

    /**
     * @brief Packets matching subnet routes with NH pointing to router interface
     * i.e., no neighbor entry route is present
     * (default packet action is trap)
     */
    SAI_HOSTIF_TRAP_TYPE_NEIGHBOR_MISS,

    SAI_HOSTIF_TRAP_TYPE_EXTENSIONS_RANGE_END

} sai_hostif_trap_type_extensions_t;

/**
 * @brief Host interface TX type extensions
 *
 * @flags free
 */
typedef enum _sai_hostif_tx_type_extensions_t
{
    SAI_HOSTIF_TX_TYPE_EXTENSIONS_START = SAI_HOSTIF_TX_TYPE_PIPELINE_LOOKUP,

    /** TX packet goes to the switch ASIC need to do specific OAM process */
    SAI_HOSTIF_TX_TYPE_OAM_PACKET_TX,

    /** TX packet goes to the switch ASIC need to do specific PTP process */
    SAI_HOSTIF_TX_TYPE_PTP_PACKET_TX,

    SAI_HOSTIF_TX_TYPE_EXTENSIONS_END

} sai_hostif_tx_type_extensions_t;

/**
 * @brief Host interface OAM packet TX type extensions
 */
typedef enum _sai_hostif_packet_oam_tx_type_t
{
    /** Non-OAM packet tx */
    SAI_HOSTIF_PACKET_OAM_TX_TYPE_NONE,

    /** OAM packet Loss Measurement Message/Loss Measurement Reply tx */
    SAI_HOSTIF_PACKET_OAM_TX_TYPE_LM,

    /** OAM packet Delay Measurement Message/Delay Measurement Reply tx */
    SAI_HOSTIF_PACKET_OAM_TX_TYPE_DM,

    /**
     * @brief OAM packet other tx
     * indicate those OAM packet do not need extra edit in ASIC
     * like link trace Message/link trace Reply Message, Alarm Indication Signal, Loopback Message/Loopback Reply Message, Automatic Protection Switching Message
     */
    SAI_HOSTIF_PACKET_OAM_TX_TYPE_OTHER,

} sai_hostif_packet_oam_tx_type_t;

typedef enum _sai_hostif_packet_ptp_tx_packet_op_type_t
{
    /**
     * @brief PTP event packet for below packet
     *
     * 1-step sync
     *
     * update TS and CF in PTP packet, do not notify
     */
    SAI_HOSTIF_PACKET_PTP_TX_PACKET_OP_TYPE_1,

    /**
     * @brief PTP event packet for below packet
     *
     * 2-step sync
     * delay-request/peer delay-request
     * 2-step peer delay-response
     *
     * update CF in PTP packet, do notify
     */
    SAI_HOSTIF_PACKET_PTP_TX_PACKET_OP_TYPE_2,

    /**
     * @brief PTP event packet for below packet
     *
     * 1-step peer delay-response
     *
     * update CF in PTP packet, do not notify
     */
    SAI_HOSTIF_PACKET_PTP_TX_PACKET_OP_TYPE_3,

} sai_hostif_packet_ptp_tx_packet_op_type_t;

/**
 * @brief Host interface packet attributes extensions
 *
 * @flags free
 */
typedef enum _sai_hostif_packet_attr_extensions_t
{
    SAI_HOSTIF_PACKET_ATTR_EXTENSIONS_RANGE_START = SAI_HOSTIF_PACKET_ATTR_END,

    /**
     * @brief Local counter for in-profile data frames received from the peer Maintenance End Point for Y.1731 Loss Measurement (for receive-only)
     *
     * The local counter for in-profile data frames received from the peer Maintenance End Point on which the Loss Measurement packet was received.
     *
     * @type sai_uint64_t
     * @flags READ_ONLY
     */
    SAI_HOSTIF_PACKET_ATTR_Y1731_RXFCL = SAI_HOSTIF_PACKET_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief OAM Tx packet type (for transmit-only)
     * indicate special process in ASIC while different OAM packet type
     *
     * @type sai_hostif_packet_oam_tx_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_OAM_TX_TYPE,

    /**
     * @brief OAM Session ID
     *
     * get transmit info from Y.1731 Session
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_Y1731_SESSION
     */
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_OAM_Y1731_SESSION_ID,

    /**
     * @brief Timestamp edit offset in packet (for transmit-only)
     *
     * Used for OAM Delay Measurement or PTP packet
     * When used for OAM Delay Measurement, it indicate the offset of timestamp which is need to edit
     * When used for PTP, it indicate the offset of PTP header in packet
     *
     * @type sai_uint32_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_HOSTIF_PACKET_ATTR_CUSTOM_OAM_TX_TYPE == SAI_HOSTIF_PACKET_OAM_TX_TYPE_DM or SAI_HOSTIF_PACKET_ATTR_HOSTIF_TX_TYPE == SAI_HOSTIF_TX_TYPE_PTP_PACKET_TX
     */
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_TIMESTAMP_OFFSET,

    /**
     * @brief PTP tx packet operation type (for transmit-only)
     *
     * PTP packet tx use 1-step or 2-step, packet need update timestamp in ASIC(Sync/Delay Request/Peer Delay Request/Peer Delay Response)
     * or not(Follow Up)
     *
     * @type sai_hostif_packet_ptp_tx_packet_op_type_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_HOSTIF_PACKET_ATTR_HOSTIF_TX_TYPE == SAI_HOSTIF_TX_TYPE_PTP_PACKET_TX
     */
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_PTP_TX_PACKET_OP_TYPE,

    /**
     * @brief Timestamp
     *
     * The timestamp set in PTP peer delay-response T2.
     * Valid when SAI_HOSTIF_PACKET_ATTR_CUSTOM_PTP_TX_PACKET_OP_TYPE == SAI_HOSTIF_PACKET_PTP_TX_PACKET_OP_TYPE_3
     *
     * @type sai_timespec_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_HOSTIF_PACKET_ATTR_TX_TIMESTAMP,

    SAI_HOSTIF_PACKET_ATTR_EXTENSIONS_RANGE_END

} sai_hostif_packet_attr_extensions_t;

typedef struct _sai_packet_event_ptp_tx_notification_data_t
{
    /**
     * @brief Tx port
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t tx_port;

    /** PTP message type */
    uint8_t msg_type;

    /** Attributes count */
    uint16_t ptp_seq_id;

    sai_timespec_t tx_timestamp;

} sai_packet_event_ptp_tx_notification_data_t;

/**
 * @brief PTP Packet tx notification callback
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Pointer to packet event notification for PTP tx data array
 */
typedef void (*sai_packet_event_ptp_tx_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_packet_event_ptp_tx_notification_data_t *data);

#endif /** __SAIHOSTIFEXTENSIONS_H_ */

