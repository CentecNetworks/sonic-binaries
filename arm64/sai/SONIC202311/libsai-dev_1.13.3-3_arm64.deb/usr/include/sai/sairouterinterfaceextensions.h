/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    sairouterinterfaceextensions.h
 *
 * @brief   This module defines SAI Router interface extensions
 */

#ifndef __SAIROUTERINTERFACEEXTENSIONS_H_
#define __SAIROUTERINTERFACEEXTENSIONS_H_

#include <sai.h>

typedef enum _sai_router_interface_rpf_check_mode_t
{
    /** Disable router interface RPF check */
    SAI_ROUTER_INTERFACE_RPF_CHECK_MODE_DISABLE,

    /** Router interface RPF check loose mode */
    SAI_ROUTER_INTERFACE_RPF_CHECK_MODE_LOOSE,

    /** Router interface RPF check strict mode */
    SAI_ROUTER_INTERFACE_RPF_CHECK_MODE_STRICT,

} sai_router_interface_rpf_check_mode_t;

/**
 * @brief Routing interface attribute IDs extensions
 *
 * @flags free
 */
typedef enum _sai_router_interface_attr_extensions_t
{
    SAI_ROUTER_INTERFACE_ATTR_EXTENSIONS_RANGE_START = SAI_ROUTER_INTERFACE_ATTR_END,

    /**
     * @brief Enable DSCP -> TC MAP on port
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on router interface.
     * To enable/disable trust DSCP, map ID should be added/removed on router interface.
     * Default no map.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_QOS_DSCP_TO_TC_MAP = SAI_ROUTER_INTERFACE_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Enable DSCP -> COLOR MAP on router interface
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on port.
     * To enable/disable trust DSCP, map ID should be added/removed on router interface.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_QOS_DSCP_TO_COLOR_MAP,

    /**
     * @brief Enable TC AND COLOR -> DSCP MAP
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on router interface.
     * Default no map.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_QOS_TC_AND_COLOR_TO_DSCP_MAP,

    /**
     * @brief Update DSCP of outgoing packets
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_ROUTER_INTERFACE_ATTR_UPDATE_DSCP,

    /**
     * @brief Admin stats state
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_STATS_STATE,

    /**
     * @brief Policer id for sub interface or Q-in-Q interface
     *
     * for L3 Virtual Private Network Access interface
     * set to NULL means disable policer on router interface
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_POLICER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_SUB_PORT or SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_QINQ_PORT
     */
    SAI_ROUTER_INTERFACE_ATTR_POLICER_ID,

    /**
     * @brief Service id for sub interface or Q-in-Q interface
     *
     * used for H-QOS, set to service schedule group service id
     * set to 0 means disable H-QOS on sub interface or Q-in-Q interface
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     * @validonly SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_SUB_PORT or SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_QINQ_PORT
     */
    SAI_ROUTER_INTERFACE_ATTR_SERVICE_ID,

    /**
     * @brief Enable DOT1P -> TC MAP on sub port router interface
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on port.
     * To enable/disable trust Dot1p, map ID should be added/removed on port.
     * Default no map.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_SUB_PORT or SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_QINQ_PORT
     */
    SAI_ROUTER_INTERFACE_ATTR_QOS_DOT1P_TO_TC_MAP,

    /**
     * @brief Enable DOT1P -> COLOR MAP on sub port router interface
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on port.
     * To enable/disable trust Dot1p, map ID should be added/removed on port.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_SUB_PORT or SAI_ROUTER_INTERFACE_ATTR_TYPE == SAI_ROUTER_INTERFACE_TYPE_QINQ_PORT
     */
    SAI_ROUTER_INTERFACE_ATTR_QOS_DOT1P_TO_COLOR_MAP,

    /**
     * @brief RPF check mode
     *
     * @type sai_router_interface_rpf_check_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_ROUTER_INTERFACE_RPF_CHECK_MODE_DISABLE
     */
    SAI_ROUTER_INTERFACE_ATTR_RPF_CHECK_MODE,

    SAI_ROUTER_INTERFACE_ATTR_EXTENSIONS_RANGE_END

} sai_router_interface_attr_extensions_t;

#endif /** __SAIROUTERINTERFACEEXTENSIONS_H_ */

