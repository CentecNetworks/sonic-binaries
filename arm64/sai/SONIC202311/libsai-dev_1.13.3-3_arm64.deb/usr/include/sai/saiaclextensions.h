/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiaclextensions.h
 *
 * @brief   This module defines SAI ACL extensions interface
 */

#ifndef __SAIACLEXTENSIONS_H_
#define __SAIACLEXTENSIONS_H_

#include <sai.h>

/**
 * @brief ACL Action Type extensions
 *
 * @flags free
 */
typedef enum _sai_acl_action_type_extensions_t
{
    SAI_ACL_ACTION_TYPE_EXTENSIONS_START = 0x00002000,

    /** Set Flow Sec SC */
    SAI_ACL_ACTION_TYPE_SET_FLOW_SEC_SC = SAI_ACL_ACTION_TYPE_EXTENSIONS_START,

    /** Set Security Parameter Identify */
    SAI_ACL_ACTION_TYPE_SET_FLOW_SEC_SPI,

    /** Set MOX session */
    SAI_ACL_ACTION_TYPE_MOX_SESSION_OBJECT,

    /** Set src metadata */
    SAI_ACL_ACTION_TYPE_SET_ACL_SRC_META_DATA,

    /** Set dst metadata */
    SAI_ACL_ACTION_TYPE_SET_ACL_DST_META_DATA,

    SAI_ACL_ACTION_TYPE_EXTENSIONS_END

} sai_acl_action_type_extensions_t;

/**
 * @brief Attribute Id for sai_acl_table extensions
 *
 * @flags free
 */
typedef enum _sai_acl_table_attr_extensions_t
{
    SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_START = 0x00004000,

    /**
     * @brief Start of Extensions Rule Match Fields
     */
    SAI_ACL_TABLE_ATTR_EXTENSIONS_FIELD_START = SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_START + 0x1000,

    /**
     * @brief FDB Src user meta data
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_FDB_SRC_USER_META = SAI_ACL_TABLE_ATTR_EXTENSIONS_FIELD_START,

    /**
     * @brief Vlan Class user meta data
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_VLAN_CLASS_USER_META,

    /**
     * @brief Dst MAC address match
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_MACDA_HIT,

    /**
     * @brief Src MAC address match
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_MACSA_HIT,

    /**
     * @brief Interface id defined
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_INTERFACE_ID,

    /**
     * @brief Virtual Router defined
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_VRF_ID,

    /**
     * @brief Security Parameter Identify
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_FLOWSEC_SPI,

    /**
     * @brief Src Metadata carried from previous ACL Stage
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_ACL_SRC_USER_META,

    /**
     * @brief Dst Metadata carried from previous ACL Stage
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_ACL_DST_USER_META,

    /**
     * @brief Packet Forward Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_PACKET_FORWARD_TYPE,

    /**
     * @brief Discard Type
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_FIELD_DISCARD_TYPE,

    /**
     * @brief End of Extensions Rule Match Fields
     */
    SAI_ACL_TABLE_ATTR_EXTENSIONS_FIELD_END = SAI_ACL_TABLE_ATTR_FIELD_DISCARD_TYPE,

    SAI_ACL_TABLE_ATTR_EXTENSIONS_RANGE_END

} sai_acl_table_attr_extensions_t;

/**
 * @brief Attribute Id for sai_acl_entry extensions
 *
 * @flags free
 */
typedef enum _sai_acl_entry_attr_extensions_t
{
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_START = 0x00004000,

    /**
     * @brief Start of Extensions Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_FIELD_START = SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_START + 0x1000,

    /**
     * @brief Src MAC address match user meta data in FDB
     *
     * Value must be in the range defined in
     * #SAI_SWITCH_ATTR_FDB_SRC_USER_META_DATA_RANGE
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_FDB_SRC_USER_META = SAI_ACL_ENTRY_ATTR_EXTENSIONS_FIELD_START,

    /**
     * @brief VLAN Class user meta data
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_VLAN_CLASS_USER_META,

    /**
     * @brief Dst MAC address match
     *
     * @type sai_acl_field_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_MACDA_HIT,

    /**
     * @brief Src MAC address match
     *
     * @type sai_acl_field_data_t bool
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_MACSA_HIT,

    /**
     * @brief Interface id defined
     *
     * @type sai_acl_field_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_ROUTER_INTERFACE
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_INTERFACE_ID,

    /**
     * @brief Virtual Router defined
     *
     * @type sai_acl_field_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_VIRTUAL_ROUTER
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_VRF_ID,

    /**
     * @brief Security Parameter Identify
     *
     * @type sai_acl_field_data_t sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_FLOWSEC_SPI,

    /**
     * @brief Src Metadata carried from previous ACL stage.
     *
     * When an ACL entry set the meta data, the ACL metadata
     * form previous stages are overridden.
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_SRC_USER_META,

    /**
     * @brief Dst Metadata carried from previous ACL stage.
     *
     * When an ACL entry set the meta data, the ACL metadata
     * form previous stages are overridden.
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_FIELD_ACL_DST_USER_META,

    /**
     * @brief End of Extensions Rule Match Fields
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_FIELD_END = SAI_ACL_ENTRY_ATTR_FIELD_ACL_DST_USER_META,

    /**
     * @brief Start of Extensions Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_START = SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_START + 0x2000,

    /**
     * @brief Set Flow Sec SC
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MACSEC_SC
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_FLOW_SEC_SC = SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_START,

    /**
     * @brief Set Security Parameter Identify
     *
     * @type sai_acl_action_data_t sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_FLOW_SEC_SPI,

    /**
     * @brief MOX session
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MONITOR_MOX_SESSION
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_MOX_SESSION_OBJECT,

    /**
     * @brief Set src metadata to carry forward to next ACL Stage
     *
     * @type sai_acl_action_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_SRC_META_DATA,

    /**
     * @brief Set dst metadata to carry forward to next ACL Stage
     *
     * @type sai_acl_action_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_DST_META_DATA,

    /**
     * @brief End of Extensions Rule Actions
     */
    SAI_ACL_ENTRY_ATTR_EXTENSIONS_ACTION_END = SAI_ACL_ENTRY_ATTR_ACTION_SET_ACL_DST_META_DATA,

    SAI_ACL_ENTRY_ATTR_EXTENSIONS_RANGE_END

} sai_acl_entry_attr_extensions_t;

/**
 * @brief Attribute Id for ACL Range Object extensions
 *
 * @flags free
 */
typedef enum _sai_acl_range_attr_extensions_t
{
    SAI_ACL_RANGE_ATTR_EXTENSIONS_RANGE_START = SAI_ACL_RANGE_ATTR_END,

    /**
     * @brief ACL stage at which point vlan range apply
     *
     * @type sai_acl_stage_t
     * @flags CREATE_AND_SET
     * @default SAI_ACL_STAGE_INGRESS
     */
    SAI_ACL_RANGE_ATTR_ACL_STAGE = SAI_ACL_RANGE_ATTR_EXTENSIONS_RANGE_START,

    SAI_ACL_RANGE_ATTR_EXTENSIONS_RANGE_END

} sai_acl_range_attr_extensions_t;

#endif /** __SAIACLEXTENSIONS_H_ */
